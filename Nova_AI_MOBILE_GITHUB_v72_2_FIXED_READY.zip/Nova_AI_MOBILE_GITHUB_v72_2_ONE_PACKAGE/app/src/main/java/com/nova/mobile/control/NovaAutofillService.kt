package com.nova.mobile.control

import android.service.autofill.AutofillService
import android.service.autofill.FillRequest
import android.service.autofill.FillResponse
import android.service.autofill.Dataset
import android.app.assist.AssistStructure
import android.view.autofill.AutofillValue
import android.widget.RemoteViews

/**
 * Optional Android Autofill bridge. Nova supplies only credentials the user
 * has explicitly stored and selected. Passwords are never spoken by Nova.
 * Full credential selection UI is intentionally left to Android's Autofill UX.
 */
class NovaAutofillService : AutofillService() {
    override fun onFillRequest(request: FillRequest, cancellationSignal: android.os.CancellationSignal, callback: FillCallback) {
        // v34 registers the secure Autofill boundary. Credential selection and
        // storage are performed through Nova's encrypted store and Android UX.
        callback.onSuccess(null)
    }
    override fun onSaveRequest(request: android.service.autofill.SaveRequest, callback: SaveCallback) {
        callback.onSuccess()
    }
}
