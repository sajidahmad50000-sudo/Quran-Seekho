package com.nova.mobile.control

import android.graphics.BitmapFactory
import android.graphics.Rect
import java.io.File
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Screenshot + OCR coordinator. Results remain in memory and are bounded. */
class NovaAndroidMultimodalVision(private val service: NovaAccessibilityService) {
    data class VisionResult(val success: Boolean, val verified: Boolean, val message: String, val data: Map<String, Any> = emptyMap())

    fun captureAndRead(): VisionResult {
        var file: File? = null
        val latch = CountDownLatch(1)
        val requested = service.takeScreenshotToFile { f -> file = f; latch.countDown() }
        if (!requested) return VisionResult(false, false, "Android screenshot API available nahi hai.")
        if (!latch.await(5, TimeUnit.SECONDS) || file == null) return VisionResult(false, false, "Screenshot capture verify nahi hui.")
        val bitmap = BitmapFactory.decodeFile(file!!.absolutePath)
            ?: return VisionResult(false, false, "Screenshot read nahi ho saki.")
        val passwordRects = service.visualNodes().filter { it.editable && (it.label.lowercase(Locale.ROOT).contains("password") || it.label.contains("••")) }
            .map { Rect(it.boundsLeft, it.boundsTop, it.boundsRight, it.boundsBottom) }
        var ocr: NovaAndroidVision.OcrResult? = null
        val ocrLatch = CountDownLatch(1)
        NovaAndroidVision().recognize(bitmap, passwordRects) { r -> ocr = r; ocrLatch.countDown() }
        bitmap.recycle()
        if (!ocrLatch.await(8, TimeUnit.SECONDS) || ocr == null) return VisionResult(false, false, "OCR response verify nahi hui.")
        val result = ocr!!
        val blocks = result.blocks.take(120).map { mapOf("text" to it.text, "left" to it.left, "top" to it.top, "right" to it.right, "bottom" to it.bottom) }
        return VisionResult(result.success, result.success, result.message, mapOf("ocr" to blocks, "count" to blocks.size))
    }
}
