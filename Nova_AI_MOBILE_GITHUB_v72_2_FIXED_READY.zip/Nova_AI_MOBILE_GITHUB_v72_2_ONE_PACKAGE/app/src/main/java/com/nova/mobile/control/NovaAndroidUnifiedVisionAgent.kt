package com.nova.mobile.control

import android.graphics.Rect
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Unified Android vision grounding layer.
 * Combines Accessibility semantics with transient OCR regions and ranks targets
 * without inventing pixel-level understanding that the available engines cannot provide.
 */
class NovaAndroidUnifiedVisionAgent(private val service: NovaAccessibilityService) {
    data class UnifiedTarget(
        val label: String,
        val source: String,
        val score: Int,
        val bounds: Rect,
        val clickable: Boolean,
        val editable: Boolean
    )

    data class AnalyzeResult(
        val success: Boolean,
        val verified: Boolean,
        val message: String,
        val targets: List<UnifiedTarget> = emptyList(),
        val ocrCount: Int = 0
    )

    fun analyze(query: String? = null): AnalyzeResult {
        val semantic = NovaAndroidVisualIntelligence(service)
        val semanticTargets = if (query.isNullOrBlank()) emptyList() else semantic.find(query, 8).map {
            UnifiedTarget(it.label, "accessibility", it.score + 20, it.bounds, it.clickable, it.editable)
        }

        val ocrBlocks = captureOcr()
        val ocrTargets = if (query.isNullOrBlank()) ocrBlocks.map {
            UnifiedTarget(it.text, "ocr", 45, Rect(it.left, it.top, it.right, it.bottom), false, false)
        } else ocrBlocks.mapNotNull { block ->
            val score = textScore(block.text, query)
            if (score <= 0) null else UnifiedTarget(block.text, "ocr", score, Rect(block.left, block.top, block.right, block.bottom), false, false)
        }

        val merged = (semanticTargets + ocrTargets)
            .sortedByDescending { it.score }
            .distinctBy { key(it) }
            .take(10)

        val msg = when {
            query.isNullOrBlank() -> "Unified screen analysis complete: ${semantic.screen()["nodeCount"] ?: 0} UI elements aur ${ocrBlocks.size} OCR text regions mile."
            merged.isEmpty() -> "'$query' ko Accessibility/OCR dono sources mein nahi mila."
            else -> "'$query' ke ${merged.size} unified target candidates mile."
        }
        return AnalyzeResult(true, true, msg, merged, ocrBlocks.size)
    }

    fun click(query: String): Pair<Boolean, String> {
        val result = analyze(query)
        if (result.targets.isEmpty()) return false to result.message
        val top = result.targets[0]
        if (result.targets.size > 1 && top.score - result.targets[1].score < 15) {
            return false to "'$query' ke multiple close targets mile: ${result.targets.take(4).joinToString { it.label }}"
        }
        if (top.source != "accessibility" || !top.clickable) {
            return false to "'$query' OCR/visual text ke roop mein mila, lekin clickable Accessibility target verify nahi hua."
        }
        val ok = NovaAndroidUiAgent(service).click(top.label).first
        return ok to if (ok) "Unified vision se '${top.label}' click ho gaya aur target accessibility se verified tha." else "'${top.label}' click nahi ho saka."
    }

    private data class OcrRectText(val text: String, val left: Int, val top: Int, val right: Int, val bottom: Int)

    private fun captureOcr(): List<OcrRectText> {
        val latch = CountDownLatch(1)
        var result: NovaAndroidMultimodalVision.VisionResult? = null
        val vision = NovaAndroidMultimodalVision(service)
        // The v50 coordinator keeps OCR transient; reuse it here so password-region filtering remains centralized.
        Thread {
            result = vision.captureAndRead()
            latch.countDown()
        }.start()
        if (!latch.await(9, TimeUnit.SECONDS)) return emptyList()
        val blocks = result?.data?.get("ocr") as? List<*> ?: return emptyList()
        return blocks.mapNotNull { item ->
            val m = item as? Map<*, *> ?: return@mapNotNull null
            val text = m["text"] as? String ?: return@mapNotNull null
            OcrRectText(
                text,
                (m["left"] as? Number)?.toInt() ?: return@mapNotNull null,
                (m["top"] as? Number)?.toInt() ?: return@mapNotNull null,
                (m["right"] as? Number)?.toInt() ?: return@mapNotNull null,
                (m["bottom"] as? Number)?.toInt() ?: return@mapNotNull null
            )
        }
    }

    private fun textScore(text: String, query: String): Int {
        val a = normalize(text)
        val b = normalize(query)
        if (a == b) return 105
        if (a.startsWith(b)) return 90
        if (a.contains(b)) return 75
        val tokens = b.split(' ').filter { it.length > 1 }
        val hits = tokens.count { a.contains(it) }
        return if (hits == 0) 0 else 30 + hits * 12
    }

    private fun key(t: UnifiedTarget): String = "${normalize(t.label)}:${t.bounds.left}:${t.bounds.top}:${t.bounds.right}:${t.bounds.bottom}"
    private fun normalize(value: String): String = value.lowercase(Locale.ROOT).replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim()
}
