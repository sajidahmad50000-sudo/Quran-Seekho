package com.nova.mobile.control

import android.content.Context
import java.util.Locale
import java.util.UUID

/**
 * Multi-step Android task agent.
 * Plans a natural goal into safe Android actions, executes sequentially,
 * re-reads the visible UI after each step, and stops instead of guessing
 * when a step cannot be verified.
 */
class NovaAndroidTaskAgent(private val context: Context, private val router: NovaAndroidCommandRouter) {
    data class TaskStep(val index: Int, val instruction: String, val command: String, val highImpact: Boolean)
    data class TaskPlan(val goal: String, val steps: List<TaskStep>, val highImpact: Boolean)
    data class TaskResult(
        val success: Boolean,
        val verified: Boolean,
        val message: String,
        val completed: Int,
        val total: Int,
        val requiresUserAction: Boolean = false,
        val failedStep: Int? = null
    )

    fun isTaskGoal(goal: String): Boolean {
        val t = goal.lowercase(Locale.ROOT).trim()
        return t.contains(" then ") || t.contains(" phir ") || t.contains("aur phir") ||
            t.contains("uske baad") || t.contains("us ke baad") || t.contains(",") ||
            t.startsWith("task ") || t.startsWith("do task ") || t.startsWith("poora kaam") ||
            t.startsWith("complete task")
    }

    fun plan(goal: String): TaskPlan {
        val pieces = splitGoal(goal)
        val steps = pieces.mapIndexedNotNull { index, piece ->
            val command = normalizeStep(piece) ?: return@mapIndexedNotNull null
            TaskStep(index + 1, piece.trim(), command, router.isHighImpact(command))
        }
        return TaskPlan(goal, steps, steps.any { it.highImpact })
    }

    fun execute(goal: String, confirmed: Boolean = false): TaskResult {
        val plan = plan(goal)
        if (plan.steps.isEmpty()) return TaskResult(false, false, "Main is goal ko clear Android steps mein convert nahi kar saki.", 0, 0)
        if (plan.highImpact && !confirmed) return TaskResult(false, false,
            "Is Android task mein protected action hai. Confirmation chahiye: ${plan.steps.joinToString { it.command }}",
            0, plan.steps.size, requiresUserAction = true)

        val id = UUID.randomUUID().toString().replace("-", "").take(12)
        journal.save(NovaPersistentTaskStore.State(id, goal, plan.steps.map { it.command }, 0, "running", System.currentTimeMillis()))
        return executeFrom(plan, id, 0, confirmed)
    }

    /** Resume only the last durable task and only from its last completed checkpoint. */
    fun resumeLast(confirmed: Boolean = false): TaskResult {
        val saved = journal.load() ?: return TaskResult(false, false, "Koi resumable Nova task nahi mila.", 0, 0)
        if (saved.status !in setOf("running", "interrupted", "recoverable")) {
            return TaskResult(false, saved.status == "completed", "Last task resumable state mein nahi hai: ${saved.status}", saved.completed, saved.commands.size)
        }
        val steps = saved.commands.mapIndexed { i, command -> TaskStep(i + 1, command, command, router.isHighImpact(command)) }
        val plan = TaskPlan(saved.goal, steps, steps.any { it.highImpact })
        if (plan.highImpact && !confirmed) return TaskResult(false, false, "Resume se pehle protected action ki confirmation chahiye.", saved.completed, steps.size, requiresUserAction = true)
        return executeFrom(plan, saved.id, saved.completed, confirmed)
    }

    fun interrupt(reason: String = "Task interrupted") {
        val s = journal.load() ?: return
        journal.save(s.copy(status = "interrupted", updatedAt = System.currentTimeMillis(), lastMessage = reason))
    }

    fun clearSavedTask() { journal.clear() }

    private fun executeFrom(plan: TaskPlan, taskId: String, startAt: Int, confirmed: Boolean): TaskResult {
        var completed = startAt
        for (i in startAt until plan.steps.size) {
            val step = plan.steps[i]
            journal.save(NovaPersistentTaskStore.State(taskId, plan.goal, plan.steps.map { it.command }, completed, "running", System.currentTimeMillis(), "Executing step ${step.index}"))
            val before = uiSnapshot()
            val result = router.execute(step.command, confirmed = confirmed || !step.highImpact)
            if (!result.success) {
                val status = if (result.requiresUserAction) "recoverable" else "interrupted"
                journal.save(NovaPersistentTaskStore.State(taskId, plan.goal, plan.steps.map { it.command }, completed, status, System.currentTimeMillis(), result.message))
                return TaskResult(false, false, "Step ${step.index} fail hua: ${result.message}", completed, plan.steps.size, result.requiresUserAction, step.index)
            }
            val after = uiSnapshot()
            val verified = verifyStep(step, before, after, result)
            if (!verified) {
                val retry = router.execute(step.command, confirmed = confirmed || !step.highImpact)
                val retryAfter = uiSnapshot()
                if (!retry.success || !verifyStep(step, after, retryAfter, retry)) {
                    journal.save(NovaPersistentTaskStore.State(taskId, plan.goal, plan.steps.map { it.command }, completed, "recoverable", System.currentTimeMillis(), "Verification failed at step ${step.index}"))
                    return TaskResult(false, false, "Step ${step.index} execute hua lekin expected UI state verify nahi hui: ${step.instruction}", completed, plan.steps.size, failedStep = step.index)
                }
            }
            completed++
            journal.save(NovaPersistentTaskStore.State(taskId, plan.goal, plan.steps.map { it.command }, completed, "running", System.currentTimeMillis(), "Checkpoint $completed/${plan.steps.size}"))
        }
        journal.save(NovaPersistentTaskStore.State(taskId, plan.goal, plan.steps.map { it.command }, completed, "completed", System.currentTimeMillis(), "Task verified"))
        return TaskResult(true, true, "Android task complete aur verify ho gaya: $completed/${plan.steps.size} steps.", completed, plan.steps.size)
    }

    private fun splitGoal(goal: String): List<String> {
        return goal.trim()
            .replace(Regex("(?i)\\s+(?:and then|aur phir|phir|then|us ke baad|uske baad)\\s+"), "\n")
            .replace(Regex("\\s*→\\s*"), "\n")
            .replace(Regex("\\s*;\\s*"), "\n")
            .split('\n')
            .flatMap { part ->
                // Commas are useful task separators when each clause is an action.
                if (part.count { it == ',' } <= 2) part.split(',') else listOf(part)
            }
            .map { it.trim() }
            .filter { it.isNotBlank() }
    }

    private fun normalizeStep(piece: String): String? {
        val p = piece.trim()
        val t = p.lowercase(Locale.ROOT)
        if (t.isBlank()) return null
        if (Regex("(?i)^(?:open|khol|kholo)\\s+app\\s+.+").matches(p)) return p
        if (Regex("(?i)^(?:.+?)\\s+(?:ki|ka)\\s+chat\\s+(?:kholo|khol|open)$").matches(p)) {
            val name = Regex("(?i)^(.+?)\\s+(?:ki|ka)\\s+chat\\s+(?:kholo|khol|open)$").find(p)!!.groupValues[1]
            return "open chat $name"
        }
        if (Regex("(?i)^(?:message|msg)\\s+(?:field|box)\\s+(?:mein|me|in|into)\\s+.+").matches(p)) {
            val value = Regex("(?i)^(?:message|msg)\\s+(?:field|box)\\s+(?:mein|me|in|into)\\s+(.+)$").find(p)!!.groupValues[1]
                .replace(Regex("(?i)\\s+(?:likho|type|enter|fill)\\s*$"), "")
                .trim()
            return "fill $value in message"
        }
        if (Regex("(?i)^(?:likho|type|enter|fill)\\s+.+\\s+(?:in|into|mein|me)\\s+.+$").matches(p)) return p
        if (Regex("(?i)^(?:click|tap|press|dabao)\\s+.+$").matches(p)) return p
        if (Regex("(?i)^scroll\\s+(?:up|down|upar|neeche).*$").matches(p)) return p
        if (t in setOf("back", "go back", "wapas", "home", "go home", "ghar")) return p
        val appOpen = Regex("(?i)^(.+?)\\s+(?:kholo|khol|open(?:\\s+kara?o)?)$").find(p)
        if (appOpen != null && !t.contains(" chat ")) return "open app ${appOpen.groupValues[1].trim()}"
        if (Regex("(?i)^(?:open|khol|kholo)\\s+.+$").matches(p)) return p
        return null
    }

    private fun uiSnapshot(): List<String> {
        return NovaAccessibilityService.instance?.visibleUi(160) ?: emptyList()
    }

    private fun verifyStep(step: TaskStep, before: List<String>, after: List<String>, result: AndroidControlResult): Boolean {
        if (result.verified) return true
        if (after.isEmpty()) return false
        if (after != before) return true
        val command = step.command.lowercase(Locale.ROOT)
        if (command.startsWith("scroll ")) return true
        return false
    }
}
