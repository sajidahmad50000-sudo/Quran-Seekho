package com.nova.mobile.control

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Durable, small task journal used to resume interrupted Android tasks safely. */
class NovaPersistentTaskStore(context: Context) {
    data class State(
        val id: String,
        val goal: String,
        val commands: List<String>,
        val completed: Int,
        val status: String,
        val updatedAt: Long,
        val lastMessage: String = ""
    )

    private val file = File(context.filesDir, "nova_task_state.json")

    @Synchronized fun save(state: State) {
        val o = JSONObject()
            .put("id", state.id)
            .put("goal", state.goal)
            .put("commands", JSONArray(state.commands))
            .put("completed", state.completed)
            .put("status", state.status)
            .put("updatedAt", state.updatedAt)
            .put("lastMessage", state.lastMessage)
        file.writeText(o.toString(), Charsets.UTF_8)
    }

    @Synchronized fun load(): State? = try {
        if (!file.exists()) return null
        val o = JSONObject(file.readText(Charsets.UTF_8))
        val a = o.optJSONArray("commands") ?: JSONArray()
        val commands = buildList { for (i in 0 until a.length()) add(a.optString(i)) }
        State(o.optString("id"), o.optString("goal"), commands,
            o.optInt("completed", 0), o.optString("status", "unknown"),
            o.optLong("updatedAt", 0L), o.optString("lastMessage", ""))
    } catch (_: Exception) { null }

    @Synchronized fun clear() { if (file.exists()) file.delete() }
}
