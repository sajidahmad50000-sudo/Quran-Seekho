package com.nova.mobile.control

import android.content.Context
import java.io.File
import java.security.MessageDigest
import java.util.Locale

/** Smart file analysis for NovaWorkspace. No changes are made without confirmation. */
class NovaAndroidSmartFileIntelligence(private val context: Context) {
    private val root get() = File(context.filesDir, "NovaWorkspace").apply { mkdirs() }
    private fun files(): List<File> = root.walkTopDown().filter { it.isFile }.toList()
    private fun category(f: File): String = when (f.extension.lowercase(Locale.ROOT)) {
        "pdf","doc","docx","txt","md","rtf" -> "Documents"
        "xls","xlsx","xlsm","csv" -> "Spreadsheets"
        "ppt","pptx" -> "Presentations"
        "jpg","jpeg","png","gif","webp","bmp","tiff" -> "Images"
        "mp3","wav","m4a","flac" -> "Audio"
        "mp4","mkv","avi","mov","webm" -> "Video"
        "zip","rar","7z","tar","gz" -> "Archives"
        "py","js","ts","java","kt","kts","json","xml","html","css" -> "Code"
        else -> "Other"
    }
    fun analyze(): AndroidControlResult {
        val fs=files(); val groups=fs.groupingBy(::category).eachCount()
        return AndroidControlResult(true,true,"${fs.size} files analyzed.",mapOf("fileCount" to fs.size,"totalBytes" to fs.sumOf{it.length()},"categories" to groups))
    }
    fun duplicates(): AndroidControlResult {
        val bySize=files().groupBy{it.length()}; val groups=mutableListOf<Map<String,Any?>>()
        bySize.filterValues{it.size>1}.forEach { (_, candidates) ->
            candidates.groupBy{sha(it)}.filterValues{it.size>1}.forEach { (hash,same) ->
                groups += mapOf("sha256" to hash,"size" to same.first().length(),"count" to same.size,"items" to same.map{it.relativeTo(root).path})
            }
        }
        return AndroidControlResult(true,true,"${groups.size} duplicate groups found.",mapOf("groups" to groups))
    }
    fun planOrganize(): AndroidControlResult {
        val moves=files().filter{it.parentFile?.canonicalFile==root.canonicalFile}.mapNotNull { f ->
            val dir=File(root,category(f)); val dst=File(dir,f.name); mapOf("source" to f.relativeTo(root).path,"target" to dst.relativeTo(root).path,"category" to category(f))
        }
        return AndroidControlResult(true,true,"Organization plan ready for ${moves.size} files.",mapOf("moves" to moves))
    }
    fun organize(confirmed:Boolean): AndroidControlResult {
        if(!confirmed) return AndroidControlResult(false,false,"Confirmation required before organizing files.",requiresUserAction=true)
        var moved=0
        files().filter{it.parentFile?.canonicalFile==root.canonicalFile}.forEach { f ->
            val dir=File(root,category(f)); dir.mkdirs(); var dst=File(dir,f.name)
            if(dst.exists()) dst=File(dir,f.nameWithoutExtension+" - organized."+f.extension)
            if(f.renameTo(dst)) moved++
        }
        return AndroidControlResult(true,true,"Organized $moved files.",mapOf("moved" to moved))
    }
    private fun sha(f:File):String { val md=MessageDigest.getInstance("SHA-256"); f.inputStream().buffered().use { input -> val b=ByteArray(8192); while(true){val n=input.read(b);if(n<0)break;md.update(b,0,n)} }; return md.digest().joinToString(""){"%02x".format(it)} }
}
