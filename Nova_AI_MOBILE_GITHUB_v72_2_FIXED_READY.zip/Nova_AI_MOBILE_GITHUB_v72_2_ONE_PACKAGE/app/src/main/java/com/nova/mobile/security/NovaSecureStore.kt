package com.nova.mobile.security

import android.content.Context
import android.util.Base64
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class NovaSecureStore(context: Context) {
    private val prefs = context.getSharedPreferences("nova_secure", Context.MODE_PRIVATE)
    private val alias = "NovaCredentialKey"
    private val ks: KeyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }

    private fun key(): SecretKey {
        val existing = ks.getKey(alias, null) as? SecretKey
        if (existing != null) return existing
        val generator = KeyGenerator.getInstance("AES", "AndroidKeyStore")
        generator.init(android.security.keystore.KeyGenParameterSpec.Builder(
            alias,
            android.security.keystore.KeyProperties.PURPOSE_ENCRYPT or android.security.keystore.KeyProperties.PURPOSE_DECRYPT
        ).setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
            .setUserAuthenticationRequired(false).build())
        return generator.generateKey()
    }

    private fun protect(value: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        return Base64.encodeToString(cipher.iv + cipher.doFinal(value.toByteArray(StandardCharsets.UTF_8)), Base64.NO_WRAP)
    }

    private fun unprotect(value: String): String? = runCatching {
        val raw = Base64.decode(value, Base64.NO_WRAP)
        require(raw.size > 12)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, raw.copyOfRange(0, 12)))
        String(cipher.doFinal(raw.copyOfRange(12, raw.size)), StandardCharsets.UTF_8)
    }.getOrNull()

    var token: String?
        get() = prefs.getString("token", null)?.let(::unprotect)
        set(value) = prefs.edit().putString("token", value?.let(::protect)).apply()

    var secret: String?
        get() = prefs.getString("secret", null)?.let(::unprotect)
        set(value) = prefs.edit().putString("secret", value?.let(::protect)).apply()

    var tokenExpiresAt: Long
        get() = prefs.getLong("token_expires_at", 0L)
        set(value) = prefs.edit().putLong("token_expires_at", value).apply()

    fun tokenExpired(nowMs: Long = System.currentTimeMillis()): Boolean = tokenExpiresAt > 0L && tokenExpiresAt * 1000L <= nowMs

    var role: String
        get() = prefs.getString("role", "viewer") ?: "viewer"
        set(value) = prefs.edit().putString("role", value).apply()

    fun clear() = prefs.edit().clear().apply()
}
