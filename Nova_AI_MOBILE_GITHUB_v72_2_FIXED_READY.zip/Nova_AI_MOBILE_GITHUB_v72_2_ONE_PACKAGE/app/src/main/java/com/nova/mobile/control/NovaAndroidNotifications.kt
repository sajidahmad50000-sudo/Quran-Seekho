package com.nova.mobile.control

import android.content.Context
import android.content.Intent
import android.provider.Settings
import org.json.JSONArray

class NovaAndroidNotifications(private val context: Context) {
    fun status(): AndroidControlResult {
        val ready=NovaNotificationListenerService.available()
        return AndroidControlResult(true, true, if(ready) "Notification access is active." else "Notification access is not enabled. Open Notification Access settings.", mapOf("available" to ready), !ready)
    }
    fun openSettings(): AndroidControlResult = try {
        context.startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        AndroidControlResult(true,true,"Notification Access settings opened.")
    } catch(e:Exception) { AndroidControlResult(false,false,"Could not open Notification Access settings: ${e.message}") }
    fun list(query:String="", unread:Boolean=false, important:Boolean=false): AndroidControlResult {
        val svc=NovaNotificationListenerService.instance ?: return AndroidControlResult(false,false,"Nova Notification Access enable karein.",requiresUserAction=true)
        val rows=svc.list(query,unread,important)
        return AndroidControlResult(true,true,"Notifications ready.",mapOf("notifications" to JSONArray(rows.toString()).toString()))
    }
}
