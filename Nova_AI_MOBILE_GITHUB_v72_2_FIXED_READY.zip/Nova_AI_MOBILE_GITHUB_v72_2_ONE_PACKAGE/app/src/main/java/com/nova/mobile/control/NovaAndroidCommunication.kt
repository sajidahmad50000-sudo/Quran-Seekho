package com.nova.mobile.control

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import java.net.URLEncoder

class NovaAndroidCommunication(private val context: Context) {
    private fun result(intent: Intent, label: String): AndroidControlResult = try {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        AndroidControlResult(true, true, "$label opened. Delivery status is not claimed.")
    } catch (e: Exception) { AndroidControlResult(false, false, "Could not open $label: ${e.message}") }

    fun call(phone: String, confirmed: Boolean): AndroidControlResult {
        if (!confirmed) return AndroidControlResult(false,false,"Call $phone? Please confirm.",requiresUserAction=true)
        return result(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(phone)}")),"Phone dialer")
    }
    fun sms(phone: String, body: String, confirmed: Boolean): AndroidControlResult {
        if (!confirmed) return AndroidControlResult(false,false,"Send SMS to $phone: $body? Please confirm.",requiresUserAction=true)
        return result(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${Uri.encode(phone)}")).apply { putExtra("sms_body",body) },"SMS composer")
    }
    fun email(email: String, subject: String, body: String, confirmed: Boolean): AndroidControlResult {
        if (!confirmed) return AndroidControlResult(false,false,"Send email to $email with subject '$subject'? Please confirm.",requiresUserAction=true)
        return result(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:${Uri.encode(email)}")).apply { putExtra(Intent.EXTRA_SUBJECT,subject); putExtra(Intent.EXTRA_TEXT,body) },"Email composer")
    }
    fun whatsapp(phone: String, body: String, confirmed: Boolean): AndroidControlResult {
        if (!confirmed) return AndroidControlResult(false,false,"Open WhatsApp message to $phone: $body? Please confirm.",requiresUserAction=true)
        val clean=phone.filter { it.isDigit() || it=='+' }.removePrefix("+")
        val encoded=URLEncoder.encode(body,"UTF-8")
        return result(Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/$clean?text=$encoded")),"WhatsApp")
    }
}
