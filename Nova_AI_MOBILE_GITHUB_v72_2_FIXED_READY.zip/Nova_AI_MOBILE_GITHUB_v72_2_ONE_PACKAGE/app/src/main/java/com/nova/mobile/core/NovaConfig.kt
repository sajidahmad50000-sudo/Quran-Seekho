package com.nova.mobile.core

import android.content.Context

data class NovaConfig(
    val pcPort: Int = 8765,
    val requestTimeoutMs: Int = 5000,
    val language: String = "ROMAN_URDU"
)

object NovaConfigStore {
    private const val PREFS = "nova_config"

    fun load(context: Context): NovaConfig {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return NovaConfig(
            pcPort = p.getInt("pc_port", 8765),
            requestTimeoutMs = p.getInt("request_timeout_ms", 5000),
            language = p.getString("language", "ROMAN_URDU") ?: "ROMAN_URDU"
        )
    }

    fun save(context: Context, config: NovaConfig) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt("pc_port", config.pcPort)
            .putInt("request_timeout_ms", config.requestTimeoutMs)
            .putString("language", config.language)
            .apply()
    }
}
