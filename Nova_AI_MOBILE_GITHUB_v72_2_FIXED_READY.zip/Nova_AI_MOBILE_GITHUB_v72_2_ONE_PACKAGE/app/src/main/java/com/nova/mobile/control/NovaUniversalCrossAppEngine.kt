package com.nova.mobile.control

import android.content.Context
import java.util.Locale
import java.util.UUID

/**
 * v69 Universal Cross-App Action Engine.
 * Converts common natural multi-app goals into deterministic, checkpointed steps.
 * High-impact steps remain confirmation-gated. No success is reported without verification.
 */
class NovaUniversalCrossAppEngine(private val context: Context, private val router: NovaAndroidCommandRouter) {
    data class Step(val index: Int, val command: String, val reason: String, val highImpact: Boolean)
    data class Plan(val goal: String, val steps: List<Step>)
    data class Result(val success: Boolean, val verified: Boolean, val message: String, val completed: Int, val total: Int, val requiresUserAction: Boolean = false, val failedStep: Int? = null)

    fun isCrossAppGoal(goal: String): Boolean {
        val t = goal.lowercase(Locale.ROOT)
        val apps = listOf("whatsapp", "telegram", "instagram", "gmail", "messages", "messenger", "photos", "gallery", "youtube")
        val actionWords = listOf("khol", "kholo", "open", "message", "msg", "bhejo", "send", "attach", "photo", "file", "search", "dhoondo", "click", "tap")
        return apps.any { t.contains(it) } && actionWords.count { t.contains(it) } >= 2 && (t.contains("then") || t.contains("phir") || t.contains("aur") || t.contains("baad") || t.contains("ko "))
    }

    fun plan(goal: String): Plan {
        val steps = mutableListOf<Step>()
        val t = goal.trim()
        val lower = t.lowercase(Locale.ROOT)

        val app = when {
            lower.contains("whatsapp") -> "WhatsApp"
            lower.contains("telegram") -> "Telegram"
            lower.contains("instagram") -> "Instagram"
            lower.contains("gmail") -> "Gmail"
            lower.contains("messenger") -> "Messenger"
            lower.contains("youtube") -> "YouTube"
            else -> null
        }
        if (app != null) steps += Step(steps.size + 1, "open app $app", "Open the requested app", false)

        // Contact chat intent: "Ali ko message ..." / "Ali ki chat kholo"
        val recipient = Regex("(?i)^(?:.*?)(?:whatsapp|telegram|messenger)?\\s*([A-Za-z][A-Za-z0-9 ._-]{1,40})\\s+(?:ko|ki)\\s+(?:message|msg|chat)").find(t)?.groupValues?.getOrNull(1)?.trim()
        if (recipient != null && recipient.length > 1) {
            steps += Step(steps.size + 1, "open chat $recipient", "Open the recipient chat using semantic UI matching", false)
        }

        val message = Regex("(?i)(?:message|msg|text)\\s+(?:bhejo|send(?:\\s+kar(?:o|do))?|likho)?\\s*[:\\-]?\\s*[\"\']?(.+?)[\"\']?\\s*$").find(t)?.groupValues?.getOrNull(1)?.trim()
        if (message != null && message.length > 1 && !message.equals("message", true)) {
            steps += Step(steps.size + 1, "fill $message in message", "Prepare the requested message", true)
        }

        if (lower.contains("attach") || lower.contains("photo") || lower.contains("picture") || lower.contains("file")) {
            val attachment = Regex("(?i)(?:attach|photo|picture|file)(?:\\s+)(?:named|called)?\\s*(.+?)(?:\\s+(?:and|phir|then|aur)\\s+|$)").find(t)?.groupValues?.getOrNull(1)?.trim()
            if (!attachment.isNullOrBlank() && attachment.length < 180) {
                steps += Step(steps.size + 1, "attach $attachment", "Prepare the requested attachment", true)
            }
        }

        if (lower.contains("send") || lower.contains("bhejo") || lower.contains("bhej do")) {
            steps += Step(steps.size + 1, "send message", "Send only after explicit confirmation", true)
        }
        return Plan(t, steps.distinctBy { it.command.lowercase(Locale.ROOT) })
    }

    fun execute(goal: String, confirmed: Boolean = false): Result {
        val plan = plan(goal)
        if (plan.steps.isEmpty()) return Result(false, false, "Goal ko supported cross-app steps mein convert nahi kar saki.", 0, 0)
        if (plan.steps.any { it.highImpact } && !confirmed) {
            return Result(false, false, "Is cross-app workflow mein protected action hai. Confirmation chahiye: ${plan.steps.joinToString { it.command }}", 0, plan.steps.size, true)
        }
        var completed = 0
        for (step in plan.steps) {
            val before = visibleUi()
            val r = when {
                step.command.startsWith("attach ") -> attach(step.command.removePrefix("attach ").trim(), confirmed)
                step.command == "send message" -> sendCurrentMessage(confirmed)
                else -> router.execute(step.command, confirmed || !step.highImpact)
            }
            if (!r.success) return Result(false, false, "Step ${step.index} fail hua: ${r.message}", completed, plan.steps.size, r.requiresUserAction, step.index)
            val after = visibleUi()
            if (!r.verified && after.isEmpty()) return Result(false, false, "Step ${step.index} execute hua lekin UI verification available nahi hui: ${step.reason}", completed, plan.steps.size, failedStep = step.index)
            if (!r.verified && before == after && step.command != "send message") return Result(false, false, "Step ${step.index} ka expected UI change verify nahi hua.", completed, plan.steps.size, failedStep = step.index)
            completed++
        }
        return Result(true, true, "Cross-app workflow verified: $completed/${plan.steps.size} steps.", completed, plan.steps.size)
    }

    private fun visibleUi(): List<String> = NovaAccessibilityService.instance?.visibleUi(180) ?: emptyList()

    private fun sendCurrentMessage(confirmed: Boolean): AndroidControlResult {
        if (!confirmed) return AndroidControlResult(false, false, "Message send karne se pehle confirmation chahiye.", requiresUserAction = true)
        val service = NovaAccessibilityService.instance ?: return AndroidControlResult(false, false, "Nova Accessibility Service enable karein.", requiresUserAction = true)
        val agent = NovaAndroidUiAgent(service)
        val candidates = agent.candidates("send", 5)
        if (candidates.isEmpty()) return AndroidControlResult(false, false, "Visible chat mein Send button nahi mila.")
        val (ok, msg) = agent.click("send")
        if (!ok) return AndroidControlResult(false, false, msg)
        val after = visibleUi()
        return AndroidControlResult(ok, after.isNotEmpty(), if (after.isNotEmpty()) "Send action complete; visible UI state available for verification." else "Send action hui lekin visible verification available nahi hui.")
    }

    private fun attach(target: String, confirmed: Boolean): AndroidControlResult {
        if (!confirmed) return AndroidControlResult(false, false, "Attachment prepare karne se pehle confirmation chahiye.", requiresUserAction = true)
        // v69 deliberately uses the Android chooser rather than guessing a file path.
        val intent = android.content.Intent(android.content.Intent.ACTION_GET_CONTENT).apply {
            type = if (target.lowercase(Locale.ROOT).matches(Regex(".*\\.(jpg|jpeg|png|webp)$"))) "image/*" else "*/*"
            addCategory(android.content.Intent.CATEGORY_OPENABLE)
            addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            AndroidControlResult(true, true, "Attachment picker opened for '$target'. Final attachment/send state still requires visible verification.")
        } catch (e: Exception) { AndroidControlResult(false, false, "Attachment picker open nahi ho saka: ${e.message}") }
    }
}
