package com.nova.mobile.control

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject

class NovaNotificationListenerService : NotificationListenerService() {
    companion object {
        @Volatile var instance: NovaNotificationListenerService? = null
        private const val PREFS = "nova_notifications"
        private const val KEY = "items"
        fun available() = instance != null
    }

    override fun onListenerConnected() { instance = this }
    override fun onListenerDisconnected() { if (instance === this) instance = null }

    override fun onNotificationPosted(sbn: StatusBarNotification) { store(sbn) }
    override fun onNotificationRemoved(sbn: StatusBarNotification) { /* keep history */ }

    private fun store(sbn: StatusBarNotification) {
        val n=sbn.notification
        val extras=n.extras
        val title=extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text=(extras?.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras?.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()
        val row=JSONObject().apply {
            put("id", sbn.key)
            put("package", sbn.packageName)
            put("title", title)
            put("text", text)
            put("timestamp", sbn.postTime)
            put("important", isImportant(title,text))
            put("read", false)
        }
        val prefs=getSharedPreferences(PREFS, MODE_PRIVATE)
        val old=JSONArray(prefs.getString(KEY,"[]"))
        val out=JSONArray(); var count=0
        for(i in old.length()-1 downTo 0) if(old.optJSONObject(i)?.optString("id")!=sbn.key && count++<199) out.put(old.optJSONObject(i))
        out.put(row); prefs.edit().putString(KEY,out.toString()).apply()
    }

    private fun isImportant(title:String,text:String):Boolean {
        val s="$title $text".lowercase(Locale.ROOT)
        return Regex("\\b(urgent|important|otp|verification|alert|failed|failure|error|payment|security|deadline|emergency)\\b").containsMatchIn(s)
    }

    fun list(query:String="", unread:Boolean=false, important:Boolean=false): JSONArray {
        val src=JSONArray(getSharedPreferences(PREFS,MODE_PRIVATE).getString(KEY,"[]")); val out=JSONArray(); val q=query.lowercase(Locale.ROOT)
        for(i in src.length()-1 downTo 0) {
            val o=src.optJSONObject(i) ?: continue
            val hay="${o.optString("package")} ${o.optString("title")} ${o.optString("text")}".lowercase(Locale.ROOT)
            if(q.isNotBlank() && !hay.contains(q)) continue
            if(unread && o.optBoolean("read",false)) continue
            if(important && !o.optBoolean("important",false)) continue
            out.put(o); if(out.length()>=50) break
        }
        return out
    }
}
