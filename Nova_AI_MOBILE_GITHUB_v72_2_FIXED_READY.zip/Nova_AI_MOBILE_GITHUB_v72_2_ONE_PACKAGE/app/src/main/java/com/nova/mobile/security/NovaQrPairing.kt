package com.nova.mobile.security

import android.content.Context
import android.net.Uri
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import java.net.URLDecoder

object NovaQrPairing {
    data class PairInfo(val host: String, val port: Int, val code: String, val expiresAt: Long)

    fun parse(raw: String): PairInfo? = runCatching {
        val uri = Uri.parse(raw)
        if (uri.scheme != "nova" || uri.host != "pair") return null
        val host = URLDecoder.decode(uri.getQueryParameter("host") ?: return null, "UTF-8")
        val port = (uri.getQueryParameter("port") ?: "8765").toInt()
        val code = uri.getQueryParameter("code") ?: return null
        val expires = (uri.getQueryParameter("expires") ?: "0").toLong()
        if (code.length != 6 || expires * 1000L <= System.currentTimeMillis()) return null
        PairInfo(host, port, code, expires)
    }.getOrNull()

    fun scan(context: Context, onResult: (PairInfo?) -> Unit) {
        GmsBarcodeScanning.getClient(context).startScan()
            .addOnSuccessListener { barcode: Barcode -> onResult(parse(barcode.rawValue ?: "")) }
            .addOnFailureListener { onResult(null) }
    }
}
