package com.nova.mobile.health

import android.content.Context
import com.nova.mobile.data.NovaDatabase
import java.io.File

data class HealthResult(
    val ok: Boolean,
    val checks: Map<String, Boolean>
)

object NovaHealth {
    fun check(context: Context): HealthResult {
        val dbOk = runCatching {
            NovaDatabase(context).readableDatabase.rawQuery("SELECT 1", null).use { it.moveToFirst() }
        }.getOrDefault(false)
        val storageOk = runCatching {
            File(context.filesDir, "logs").mkdirs()
            File(context.filesDir, "logs").canWrite()
        }.getOrDefault(false)
        return HealthResult(dbOk && storageOk, mapOf("database" to dbOk, "log_storage" to storageOk))
    }
}
