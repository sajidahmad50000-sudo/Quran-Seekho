# Nova AI Mobile v72.2 FIXED

Android project for building the Nova mobile APK with GitHub Actions.

## Fixed in v72.2
- Fixed Android accessibility-service resource error by moving the description text into `res/values/strings.xml`.
- Updated app version to 72.2 (versionCode 73).
- Repository-ready Gradle/Android configuration is included.

## Build
Use GitHub Actions workflow: `.github/workflows/build-apk.yml`.
The workflow produces `app/build/outputs/apk/debug/app-debug.apk`.
