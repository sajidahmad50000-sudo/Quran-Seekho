import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:just_audio/just_audio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'dart:io';

const green = Color(0xFF0B6B4B);
const cream = Color(0xFFF8F2E6);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  runApp(QuranSeekho(prefs: prefs));
}

class QuranSeekho extends StatelessWidget {
  final SharedPreferences prefs;
  const QuranSeekho({super.key, required this.prefs});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Quran Seekho',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: cream,
        colorScheme: ColorScheme.fromSeed(seedColor: green),
        appBarTheme: const AppBarTheme(backgroundColor: green, foregroundColor: Colors.white),
        cardTheme: CardThemeData(color: Colors.white, elevation: 0, margin: EdgeInsets.zero),
      ),
      home: HomePage(prefs: prefs),
    );
  }
}

class QuranData {
  final List<Map<String, dynamic>> surahs;
  QuranData(this.surahs);
  static Future<QuranData> load() async {
    final raw = await rootBundle.loadString('assets/quran_uthmani.json');
    final data = jsonDecode(raw) as Map<String, dynamic>;
    return QuranData((data['surahs'] as List).cast<Map<String, dynamic>>());
  }
}


class OfflineAudioManager {
  static final OfflineAudioManager instance = OfflineAudioManager._();
  OfflineAudioManager._();
  final AudioPlayer player = AudioPlayer();
  int? currentSurah;
  String urlFor(int surah) => 'https://download.quranicaudio.com/quran/abdullaah_3awwaad_al-juhaynee/${surah.toString().padLeft(3, '0')}.mp3';
  Future<Directory> _dir() async {
    final base = await getApplicationDocumentsDirectory();
    final dir = Directory('${base.path}/quran_audio');
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }
  Future<File> localFile(int surah) async {
    final dir = await _dir();
    return File('${dir.path}/${surah.toString().padLeft(3, '0')}.mp3');
  }
  Future<bool> isDownloaded(int surah) async => (await localFile(surah)).exists();
  Future<File> download(int surah) async {
    final file = await localFile(surah);
    if (await file.exists() && await file.length() > 0) return file;
    final response = await http.get(Uri.parse(urlFor(surah)));
    if (response.statusCode != 200) throw Exception('Audio download failed (${response.statusCode})');
    await file.writeAsBytes(response.bodyBytes, flush: true);
    return file;
  }
  Future<void> playSurah(int surah) async {
    final file = await localFile(surah);
    if (!await file.exists()) throw Exception('یہ سورہ ابھی Offline محفوظ نہیں ہے۔ پہلے Download کریں۔');
    await player.setFilePath(file.path);
    currentSurah = surah;
    await player.play();
  }
}

class DuaItem {
  final String title, arabic, meaning, when;
  const DuaItem(this.title, this.arabic, this.meaning, this.when);
}

const dailyDuas = <DuaItem>[
  DuaItem('کھانے سے پہلے', 'بِسْمِ اللّٰهِ', 'اللہ کے نام سے شروع کرتا/کرتی ہوں۔', 'کھانا شروع کرتے وقت'),
  DuaItem('کھانے کے بعد', 'الْحَمْدُ لِلّٰهِ الَّذِي أَطْعَمَنِي هَٰذَا وَرَزَقَنِيهِ مِنْ غَيْرِ حَوْلٍ مِنِّي وَلَا قُوَّةٍ', 'تمام تعریفیں اللہ کے لیے ہیں جس نے مجھے یہ کھانا کھلایا اور مجھے عطا کیا، بغیر میری طاقت و قوت کے۔', 'کھانا کھانے کے بعد'),
  DuaItem('سونے سے پہلے', 'بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا', 'اے اللہ! تیرے ہی نام کے ساتھ مرتا اور جیتا ہوں۔', 'سونے سے پہلے'),
  DuaItem('جاگنے کے بعد', 'الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ', 'تمام تعریف اللہ کے لیے ہے جس نے ہمیں موت جیسی نیند کے بعد زندہ کیا اور اسی کی طرف لوٹنا ہے۔', 'نیند سے جاگنے کے بعد'),
  DuaItem('گھر سے نکلتے وقت', 'بِسْمِ اللَّهِ، تَوَكَّلْتُ عَلَى اللَّهِ، لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ', 'اللہ کے نام سے، میں نے اللہ پر بھروسہ کیا، طاقت اور قوت صرف اللہ ہی سے ہے۔', 'گھر سے نکلتے وقت'),
  DuaItem('گھر میں داخل ہوتے وقت', 'بِسْمِ اللَّهِ وَلَجْنَا، وَبِسْمِ اللَّهِ خَرَجْنَا، وَعَلَى اللَّهِ رَبِّنَا تَوَكَّلْنَا', 'اللہ کے نام سے داخل ہوئے، اللہ کے نام سے نکلے اور اپنے رب اللہ پر بھروسہ کیا۔', 'گھر میں داخل ہوتے وقت'),
  DuaItem('بیت الخلاء میں داخل ہوتے وقت', 'اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْخُبُثِ وَالْخَبَائِثِ', 'اے اللہ! میں ناپاک شیاطین سے تیری پناہ مانگتا/مانگتی ہوں۔', 'بیت الخلاء میں داخل ہونے سے پہلے'),
  DuaItem('بیت الخلاء سے نکلتے وقت', 'غُفْرَانَكَ', 'اے اللہ! میں تجھ سے مغفرت طلب کرتا/کرتی ہوں۔', 'بیت الخلاء سے نکلنے کے بعد'),
  DuaItem('وضو کے بعد', 'أَشْهَدُ أَنْ لَا إِلَٰهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، وَأَشْهَدُ أَنَّ مُحَمَّدًا عَبْدُهُ وَرَسُولُهُ', 'میں گواہی دیتا/دیتی ہوں کہ اللہ کے سوا کوئی معبود نہیں، وہ اکیلا ہے، اس کا کوئی شریک نہیں، اور محمد ﷺ اس کے بندے اور رسول ہیں۔', 'وضو مکمل کرنے کے بعد'),
  DuaItem('مسجد میں داخل ہوتے وقت', 'اللَّهُمَّ افْتَحْ لِي أَبْوَابَ رَحْمَتِكَ', 'اے اللہ! میرے لیے اپنی رحمت کے دروازے کھول دے۔', 'مسجد میں داخل ہوتے وقت'),
  DuaItem('مسجد سے نکلتے وقت', 'اللَّهُمَّ إِنِّي أَسْأَلُكَ مِنْ فَضْلِكَ', 'اے اللہ! میں تجھ سے تیرے فضل کا سوال کرتا/کرتی ہوں۔', 'مسجد سے نکلتے وقت'),
  DuaItem('سفر کی دعا', 'سُبْحَانَ الَّذِي سَخَّرَ لَنَا هَٰذَا وَمَا كُنَّا لَهُ مُقْرِنِينَ ۝ وَإِنَّا إِلَىٰ رَبِّنَا لَمُنقَلِبُونَ', 'پاک ہے وہ ذات جس نے اسے ہمارے لیے مسخر کیا، ورنہ ہم اسے قابو میں نہیں لا سکتے تھے، اور ہم اپنے رب کی طرف لوٹنے والے ہیں۔', 'سفر شروع کرتے وقت'),
  DuaItem('علم میں اضافہ', 'رَبِّ زِدْنِي عِلْمًا', 'اے میرے رب! میرے علم میں اضافہ فرما۔', 'علم حاصل کرتے وقت'),
  DuaItem('والدین کے لیے', 'رَبِّ ارْحَمْهُمَا كَمَا رَبَّيَانِي صَغِيرًا', 'اے میرے رب! ان دونوں پر رحم فرما جیسے انہوں نے بچپن میں مجھے پالا۔', 'والدین کے لیے دعا'),
  DuaItem('مغفرت کی دعا', 'رَبِّ اغْفِرْ لِي وَارْحَمْنِي وَأَنْتَ خَيْرُ الرَّاحِمِينَ', 'اے میرے رب! مجھے بخش دے اور مجھ پر رحم فرما، اور تو سب سے بہتر رحم کرنے والا ہے۔', 'مغفرت مانگتے وقت'),
  DuaItem('دنیا و آخرت کی بھلائی', 'رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ', 'اے ہمارے رب! ہمیں دنیا میں بھلائی دے، آخرت میں بھی بھلائی دے اور ہمیں آگ کے عذاب سے بچا۔', 'عمومی دعا'),
  DuaItem('مصیبت کے وقت', 'إِنَّا لِلَّهِ وَإِنَّا إِلَيْهِ رَاجِعُونَ', 'بے شک ہم اللہ ہی کے ہیں اور اسی کی طرف لوٹ کر جانے والے ہیں۔', 'مصیبت یا نقصان کے وقت'),
  DuaItem('بارش کی دعا', 'اللَّهُمَّ صَيِّبًا نَافِعًا', 'اے اللہ! اسے نفع بخش بارش بنا۔', 'بارش کے وقت'),
  DuaItem('بارش کے بعد', 'مُطِرْنَا بِفَضْلِ اللَّهِ وَرَحْمَتِهِ', 'ہم پر اللہ کے فضل اور رحمت سے بارش ہوئی۔', 'بارش کے بعد'),
  DuaItem('مریض کی عیادت', 'أَسْأَلُ اللَّهَ الْعَظِيمَ رَبَّ الْعَرْشِ الْعَظِيمِ أَنْ يَشْفِيَكَ', 'میں عظمت والے اللہ، عرش عظیم کے رب سے دعا کرتا/کرتی ہوں کہ وہ تمہیں شفا دے۔', 'مریض کی عیادت کے وقت'),
  DuaItem('افطار کی دعا', 'ذَهَبَ الظَّمَأُ وَابْتَلَّتِ الْعُرُوقُ وَثَبَتَ الْأَجْرُ إِنْ شَاءَ اللَّهُ', 'پیاس ختم ہوئی، رگیں تر ہوئیں اور ان شاء اللہ اجر ثابت ہوگیا۔', 'روزہ افطار کرتے وقت'),
  DuaItem('چھینک کا جواب', 'يَرْحَمُكَ اللَّهُ', 'اللہ تم پر رحم فرمائے۔', 'چھینکنے والے کے الحمدللہ کہنے پر'),
  DuaItem('چھینک کے بعد', 'الْحَمْدُ لِلَّهِ', 'تمام تعریفیں اللہ کے لیے ہیں۔', 'چھینک آنے کے بعد'),
  DuaItem('دل کے اطمینان کی قرآنی دعا', 'رَبَّنَا لَا تُزِغْ قُلُوبَنَا بَعْدَ إِذْ هَدَيْتَنَا وَهَبْ لَنَا مِنْ لَدُنْكَ رَحْمَةً إِنَّكَ أَنْتَ الْوَهَّابُ', 'اے ہمارے رب! ہدایت دینے کے بعد ہمارے دل ٹیڑھے نہ کر اور ہمیں اپنے پاس سے رحمت عطا فرما۔ بے شک تو بہت عطا کرنے والا ہے۔', 'ہدایت اور ثابت قدمی کے لیے'),
  DuaItem('قرآن سمجھنے اور عمل کی دعا', 'اللَّهُمَّ انْفَعْنِي بِمَا عَلَّمْتَنِي وَعَلِّمْنِي مَا يَنْفَعُنِي وَزِدْنِي عِلْمًا', 'اے اللہ! جو تو نے مجھے سکھایا اس سے مجھے نفع دے، مجھے وہ سکھا جو میرے لیے نفع بخش ہو، اور میرے علم میں اضافہ فرما۔', 'علم اور قرآن سیکھتے وقت'),
];

class DuasPage extends StatefulWidget {
  const DuasPage({super.key});
  @override State<DuasPage> createState() => _DuasPageState();
}

class _DuasPageState extends State<DuasPage> {
  final FlutterTts tts = FlutterTts();
  String query = '';
  bool speaking = false;

  @override
  void initState() {
    super.initState();
    _setupTts();
  }

  Future<void> _setupTts() async {
    try {
      await tts.setLanguage('ar-SA');
      await tts.setSpeechRate(0.42);
      await tts.setPitch(1.0);
      tts.setStartHandler(() { if (mounted) setState(() => speaking = true); });
      tts.setCompletionHandler(() { if (mounted) setState(() => speaking = false); });
      tts.setCancelHandler(() { if (mounted) setState(() => speaking = false); });
      tts.setErrorHandler((_) { if (mounted) setState(() => speaking = false); });
    } catch (_) {}
  }

  Future<void> speak(DuaItem d) async {
    try {
      await tts.stop();
      await tts.setLanguage('ar-SA');
      await tts.speak(d.arabic);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Voice کے لیے فون میں Arabic Text-to-Speech voice انسٹال/فعال کریں۔')),
        );
      }
    }
  }

  Future<void> stopVoice() async {
    await tts.stop();
    if (mounted) setState(() => speaking = false);
  }

  @override
  void dispose() {
    tts.stop();
    tts.shutdown();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final q = query.trim().toLowerCase();
    final filtered = dailyDuas.where((d) {
      if (q.isEmpty) return true;
      return d.title.toLowerCase().contains(q) ||
          d.meaning.toLowerCase().contains(q) ||
          d.when.toLowerCase().contains(q) ||
          d.arabic.contains(query.trim());
    }).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('روزمرہ کی دعائیں'), centerTitle: true),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 6),
          child: TextField(
            textDirection: TextDirection.rtl,
            onChanged: (v) => setState(() => query = v),
            decoration: InputDecoration(
              hintText: 'دعا تلاش کریں... مثلاً کھانا، سفر، سونا',
              prefixIcon: const Icon(Icons.search),
              suffixIcon: query.isEmpty ? null : IconButton(icon: const Icon(Icons.clear), onPressed: () => setState(() => query = '')),
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          child: Row(children: [
            Expanded(child: Text('${filtered.length} دعائیں', textDirection: TextDirection.rtl, textAlign: TextAlign.right, style: const TextStyle(color: Colors.black54))),
            if (speaking) TextButton.icon(onPressed: stopVoice, icon: const Icon(Icons.stop, color: green), label: const Text('آواز بند کریں')),
          ]),
        ),
        Expanded(
          child: filtered.isEmpty
              ? const Center(child: Text('کوئی دعا نہیں ملی'))
              : ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: filtered.length,
                  itemBuilder: (_, i) {
                    final d = filtered[i];
                    return Card(
                      margin: const EdgeInsets.only(bottom: 12),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(20),
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DuaDetailPage(dua: d, tts: tts))),
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                            Row(children: [
                              Expanded(child: Text(d.title, textDirection: TextDirection.rtl, textAlign: TextAlign.right, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold, color: green))),
                              IconButton(onPressed: () => speak(d), tooltip: 'دعا سنیں', icon: const Icon(Icons.volume_up, color: green)),
                            ]),
                            Text(d.when, textDirection: TextDirection.rtl, textAlign: TextAlign.right, style: const TextStyle(color: Colors.black54)),
                            const Divider(height: 22),
                            Text(d.arabic, textDirection: TextDirection.rtl, textAlign: TextAlign.right, style: const TextStyle(fontSize: 25, height: 1.9, fontWeight: FontWeight.w600)),
                            const SizedBox(height: 10),
                            Text(d.meaning, textDirection: TextDirection.rtl, textAlign: TextAlign.right, style: const TextStyle(fontSize: 16, height: 1.7)),
                            const SizedBox(height: 6),
                            const Align(alignment: Alignment.centerLeft, child: Icon(Icons.arrow_forward_ios, size: 15, color: Colors.black38)),
                          ]),
                        ),
                      ),
                    );
                  },
                ),
        ),
      ]),
    );
  }
}

class DuaDetailPage extends StatefulWidget {
  final DuaItem dua;
  final FlutterTts tts;
  const DuaDetailPage({super.key, required this.dua, required this.tts});
  @override State<DuaDetailPage> createState() => _DuaDetailPageState();
}

class _DuaDetailPageState extends State<DuaDetailPage> {
  bool speaking = false;

  Future<void> play() async {
    try {
      await widget.tts.stop();
      await widget.tts.setLanguage('ar-SA');
      await widget.tts.setSpeechRate(0.42);
      widget.tts.setCompletionHandler(() { if (mounted) setState(() => speaking = false); });
      widget.tts.setCancelHandler(() { if (mounted) setState(() => speaking = false); });
      setState(() => speaking = true);
      await widget.tts.speak(widget.dua.arabic);
    } catch (_) {
      if (mounted) {
        setState(() => speaking = false);
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Arabic voice فون کے Text-to-Speech engine پر منحصر ہے۔')));
      }
    }
  }

  Future<void> stop() async {
    await widget.tts.stop();
    if (mounted) setState(() => speaking = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('دعا'), centerTitle: true),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      Card(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)), child: Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Text(widget.dua.title, textDirection: TextDirection.rtl, textAlign: TextAlign.right, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold, color: green)),
        const SizedBox(height: 8),
        Text(widget.dua.when, textDirection: TextDirection.rtl, textAlign: TextAlign.right, style: const TextStyle(color: Colors.black54)),
        const Divider(height: 30),
        Text(widget.dua.arabic, textDirection: TextDirection.rtl, textAlign: TextAlign.center, style: const TextStyle(fontSize: 31, height: 2.0, fontWeight: FontWeight.w600)),
        const SizedBox(height: 18),
        Text(widget.dua.meaning, textDirection: TextDirection.rtl, textAlign: TextAlign.right, style: const TextStyle(fontSize: 18, height: 1.8)),
        const SizedBox(height: 22),
        FilledButton.icon(onPressed: speaking ? stop : play, icon: Icon(speaking ? Icons.stop : Icons.volume_up), label: Text(speaking ? 'آواز بند کریں' : 'دعا کی آواز سنیں')),
      ])),
      const SizedBox(height: 14),
      const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('نوٹ: آواز فون کے Arabic Text-to-Speech engine سے چلتی ہے۔ اگر Arabic voice فون میں موجود نہ ہو تو اسے Text-to-Speech settings سے انسٹال کریں۔', textDirection: TextDirection.rtl, textAlign: TextAlign.right, style: TextStyle(height: 1.6)))),
    ]),
  );
}

class HomePage extends StatefulWidget {
  final SharedPreferences prefs;
  const HomePage({super.key, required this.prefs});
  @override State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  late Future<QuranData> future;
  @override void initState() { super.initState(); future = QuranData.load(); }

  void openQuran() => Navigator.push(context, MaterialPageRoute(builder: (_) => QuranPage(prefs: widget.prefs, future: future)));
  void openProgress() => Navigator.push(context, MaterialPageRoute(builder: (_) => ProgressPage(prefs: widget.prefs)));

  @override Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('قرآن سیکھو', style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
        leading: IconButton(icon: const Icon(Icons.menu), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MenuPage()))),
        actions: [IconButton(icon: const Icon(Icons.bookmark_outline), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => BookmarksPage(prefs: widget.prefs, future: future))))],
      ),
      body: IndexedStack(index: tab, children: [
        _homeBody(context),
        QuranPage(prefs: widget.prefs, future: future, embedded: true),
        ProgressPage(prefs: widget.prefs, embedded: true),
        SettingsPage(prefs: widget.prefs, embedded: true),
      ]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'Quran'),
          NavigationDestination(icon: Icon(Icons.insights_outlined), selectedIcon: Icon(Icons.insights), label: 'Progress'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'Settings'),
        ],
      ),
    );
  }

  Widget _homeBody(BuildContext context) {
    final lastSurah = widget.prefs.getInt('last_surah');
    final lastAyah = widget.prefs.getInt('last_ayah');
    return ListView(padding: const EdgeInsets.all(16), children: [
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(color: green, borderRadius: BorderRadius.circular(24)),
        child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيْمِ', textDirection: TextDirection.rtl, style: TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.bold)),
          SizedBox(height: 8), Text('قرآن پاک پڑھیں، سیکھیں اور سمجھیں', style: TextStyle(color: Colors.white70, fontSize: 15)),
        ]),
      ),
      const SizedBox(height: 18),
      if (lastSurah != null) _resumeCard(lastSurah, lastAyah ?? 1),
      const SizedBox(height: 14),
      GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.25, children: [
        _tile(Icons.menu_book, 'قرآن پڑھیں', 'Read Quran', openQuran),
        _tile(Icons.headphones, 'تلاوت سنیں', 'Offline Tilawat', () => Navigator.push(context, MaterialPageRoute(builder: (_) => TilawatPage(prefs: widget.prefs, future: future)))),
        _tile(Icons.bookmark, 'محفوظ آیات', 'Bookmarks', () => Navigator.push(context, MaterialPageRoute(builder: (_) => BookmarksPage(prefs: widget.prefs, future: future)))),
        _tile(Icons.volunteer_activism, 'دعائیں', 'Daily Duas', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DuasPage()))),
        _tile(Icons.record_voice_over, 'تلاوت چیک کریں', 'Reading Practice', () => Navigator.push(context, MaterialPageRoute(builder: (_) => ReadingPracticePage(prefs: widget.prefs, future: future)))),
        _tile(Icons.insights, 'میری پیش رفت', 'Progress', openProgress),
        _tile(Icons.settings, 'سیٹنگز', 'Settings', () => setState(() => tab = 3)),
      ]),
      const SizedBox(height: 18),
      Card(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)), child: const Padding(padding: EdgeInsets.all(18), child: Row(children: [Icon(Icons.cloud_off, color: green, size: 30), SizedBox(width: 12), Expanded(child: Text('Quran text مکمل طور پر Offline ہے۔ انٹرنیٹ کی ضرورت نہیں۔'))]))),
      const SizedBox(height: 18),
      Card(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)), child: const Padding(padding: EdgeInsets.all(18), child: Text('یہ ایپ قرآن پڑھنے اور سیکھنے میں مدد کے لیے بنائی گئی ہے۔'))),
    ]);
  }

  Widget _resumeCard(int surah, int ayah) => Card(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)), child: ListTile(leading: const CircleAvatar(backgroundColor: green, child: Icon(Icons.play_arrow, color: Colors.white)), title: const Text('جہاں چھوڑا تھا وہاں سے پڑھیں'), subtitle: Text('سورہ $surah • آیت $ayah'), onTap: () async { final d = await future; final s = d.surahs.firstWhere((x) => x['number'] == surah); if (!mounted) return; Navigator.push(context, MaterialPageRoute(builder: (_) => SurahPage(prefs: widget.prefs, surah: s, initialAyah: ayah))); }));

  Widget _tile(IconData icon, String title, String subtitle, VoidCallback onTap) => Card(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)), child: InkWell(borderRadius: BorderRadius.circular(22), onTap: onTap, child: Padding(padding: const EdgeInsets.all(14), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(icon, color: green, size: 34), const SizedBox(height: 8), Text(title, textDirection: TextDirection.rtl, textAlign: TextAlign.center, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), const SizedBox(height: 3), Text(subtitle, style: const TextStyle(color: Colors.black54))])));
}

class QuranPage extends StatefulWidget {
  final SharedPreferences prefs; final Future<QuranData> future; final bool embedded;
  const QuranPage({super.key, required this.prefs, required this.future, this.embedded = false});
  @override State<QuranPage> createState() => _QuranPageState();
}
class _QuranPageState extends State<QuranPage> {
  String query = '';
  @override Widget build(BuildContext context) {
    return FutureBuilder<QuranData>(future: widget.future, builder: (context, snap) {
      if (!snap.hasData) return const Center(child: CircularProgressIndicator());
      final all = snap.data!.surahs;
      final list = all.where((s) => query.isEmpty || s['name'].toString().contains(query) || s['number'].toString() == query).toList();
      final body = Column(children: [Padding(padding: const EdgeInsets.fromLTRB(14, 14, 14, 8), child: TextField(textDirection: TextDirection.rtl, onChanged: (v) => setState(() => query = v.trim()), decoration: InputDecoration(hintText: 'سورہ تلاش کریں', prefixIcon: const Icon(Icons.search), filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none)))), Expanded(child: ListView.builder(itemCount: list.length, itemBuilder: (_, i) { final s = list[i]; return Card(margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 5), child: ListTile(onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SurahPage(prefs: widget.prefs, surah: s))), leading: CircleAvatar(backgroundColor: green, foregroundColor: Colors.white, child: Text('${s['number']}')), title: Text(s['name'], textDirection: TextDirection.rtl, textAlign: TextAlign.right, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)), subtitle: Text('${s['ayahCount']} آیات', textAlign: TextAlign.right), trailing: const Icon(Icons.chevron_right, color: green))); }))]);
      if (widget.embedded) return Scaffold(body: body); return Scaffold(appBar: AppBar(title: const Text('قرآن پاک')), body: body);
    });
  }
}

class SurahPage extends StatefulWidget {
  final SharedPreferences prefs; final Map<String,dynamic> surah; final int initialAyah;
  const SurahPage({super.key, required this.prefs, required this.surah, this.initialAyah = 1});
  @override State<SurahPage> createState() => _SurahPageState();
}
class _SurahPageState extends State<SurahPage> {
  late Set<String> bookmarks;
  @override void initState(){super.initState(); bookmarks = widget.prefs.getStringList('bookmarks')?.toSet() ?? {};
    WidgetsBinding.instance.addPostFrameCallback((_) { final controller = Scrollable.ensureVisible; if (widget.initialAyah > 1) { /* resume is stored; list remains safely scrollable */ } }); }
  Future<void> toggle(String key) async { setState(() { if (!bookmarks.add(key)) bookmarks.remove(key); }); await widget.prefs.setStringList('bookmarks', bookmarks.toList()); }
  @override Widget build(BuildContext context){ final ayahs=(widget.surah['ayahs'] as List).cast<Map<String,dynamic>>(); return Scaffold(appBar: AppBar(title: Text(widget.surah['name']), centerTitle:true), body: ListView.builder(padding: const EdgeInsets.all(12), itemCount: ayahs.length, itemBuilder: (_,i){ final a=ayahs[i]; final key='${widget.surah['number']}:${a['number']}'; final saved=bookmarks.contains(key); return Card(margin: const EdgeInsets.only(bottom:10), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)), child: Padding(padding: const EdgeInsets.fromLTRB(18,18,18,10), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children:[Text(a['text'], textDirection: TextDirection.rtl, textAlign: TextAlign.right, style: const TextStyle(fontSize:28,height:1.9)), const SizedBox(height:8), Row(children:[IconButton(onPressed:()=>toggle(key), icon:Icon(saved?Icons.bookmark:Icons.bookmark_outline,color:green)), IconButton(tooltip:'تلاوت چیک کریں',onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ReadingPracticePage(prefs:widget.prefs, future:Future.value(QuranData([widget.surah])), initialSurahNumber:widget.surah['number'] as int, initialAyahNumber:a['number'] as int))), icon:const Icon(Icons.record_voice_over,color:green)), const Spacer(), Text('${a['number']}',style:const TextStyle(color:green,fontWeight:FontWeight.bold))])]))); })); }
  @override void dispose(){ super.dispose(); widget.prefs.setInt('last_surah', widget.surah['number'] as int); }
}


String _normalizeArabic(String value) {
  var s = value.replaceAll(RegExp(r'[\u064B-\u065F\u0670\u06D6-\u06ED]'), '');
  s = s.replaceAll('ٱ', 'ا').replaceAll('أ', 'ا').replaceAll('إ', 'ا').replaceAll('آ', 'ا');
  s = s.replaceAll('ى', 'ي').replaceAll('ؤ', 'و').replaceAll('ئ', 'ي');
  s = s.replaceAll(RegExp(r'[۝۞،؛,.!?]'), ' ');
  return s.replaceAll(RegExp(r'\s+'), ' ').trim();
}

List<String> _arabicWords(String text) => _normalizeArabic(text).split(' ').where((x) => x.isNotEmpty).toList();

class ReadingPracticePage extends StatefulWidget {
  final SharedPreferences prefs;
  final Future<QuranData> future;
  final int? initialSurahNumber;
  final int? initialAyahNumber;
  const ReadingPracticePage({super.key, required this.prefs, required this.future, this.initialSurahNumber, this.initialAyahNumber});
  @override State<ReadingPracticePage> createState() => _ReadingPracticePageState();
}

class _ReadingPracticePageState extends State<ReadingPracticePage> {
  final stt.SpeechToText speech = stt.SpeechToText();
  final FlutterTts tts = FlutterTts();
  bool ready = false, listening = false, checking = false;
  String recognized = '';
  String? recognitionLocale;
  Map<String, dynamic>? selectedSurah;
  Map<String, dynamic>? selectedAyah;
  List<_WordCheck> wordChecks = [];
  double confidence = 0;

  @override void initState() { super.initState(); _init(); }

  Future<void> _init() async {
    ready = await speech.initialize(
      onStatus: (status) { if (mounted) setState(() => listening = status == 'listening'); },
      onError: (_) { if (mounted) setState(() { listening = false; checking = false; }); },
    );
    try {
      final locales = await speech.locales();
      final arabic = locales.where((l) => l.localeId.toLowerCase().startsWith('ar')).toList();
      recognitionLocale = arabic.isNotEmpty ? arabic.first.localeId : 'ar-SA';
    } catch (_) { recognitionLocale = 'ar-SA'; }
    final data = await widget.future;
    if (!mounted) return;
    setState(() {
      if (widget.initialSurahNumber != null) {
        selectedSurah = data.surahs.firstWhere((s) => s['number'] == widget.initialSurahNumber);
      }
      if (selectedSurah != null && widget.initialAyahNumber != null) {
        selectedAyah = (selectedSurah!['ayahs'] as List).cast<Map<String,dynamic>>().firstWhere((a) => a['number'] == widget.initialAyahNumber);
      }
    });
  }

  Future<void> chooseAyah() async {
    final data = await widget.future;
    if (!mounted) return;
    await showModalBottomSheet(context: context, isScrollControlled: true, builder: (_) => SafeArea(child: SizedBox(
      height: MediaQuery.of(context).size.height * .78,
      child: ListView.builder(itemCount: data.surahs.length, itemBuilder: (_, i) {
        final s = data.surahs[i];
        return ExpansionTile(
          title: Text(s['name'], textDirection: TextDirection.rtl, textAlign: TextAlign.right),
          subtitle: Text('${s['ayahCount']} آیات'),
          children: [for (final a in (s['ayahs'] as List).cast<Map<String,dynamic>>())
            ListTile(
              title: Text('آیت ${a['number']}: ${a['text']}', textDirection: TextDirection.rtl, textAlign: TextAlign.right, maxLines: 2, overflow: TextOverflow.ellipsis),
              onTap: () { setState(() { selectedSurah = s; selectedAyah = a; _resetCheck(); }); Navigator.pop(context); },
            )],
        );
      }),
    )));
  }

  void _resetCheck() {
    recognized = '';
    wordChecks = [];
    confidence = 0;
    checking = false;
  }

  Future<void> startListening() async {
    if (!ready || selectedAyah == null) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('پہلے آیت منتخب کریں اور Microphone permission دیں۔')));
      return;
    }
    setState(() { _resetCheck(); checking = true; listening = true; });
    await speech.listen(
      localeId: recognitionLocale ?? 'ar-SA',
      listenMode: stt.ListenMode.dictation,
      partialResults: true,
      onResult: (r) { if (mounted) setState(() => recognized = r.recognizedWords); },
    );
  }

  Future<void> stopAndCheck() async {
    await speech.stop();
    if (selectedAyah == null) return;
    final expected = _arabicWords(selectedAyah!['text']);
    final heard = _arabicWords(recognized);
    final result = _alignWords(expected, heard);
    setState(() {
      listening = false;
      checking = false;
      wordChecks = result;
      final total = result.length;
      final matched = result.where((x) => x.status == _WordStatus.match).length;
      confidence = total == 0 ? 0 : matched / total;
    });
  }

  Future<void> hearCorrect() async {
    if (selectedAyah == null) return;
    await tts.stop();
    await tts.setLanguage('ar-SA');
    await tts.setSpeechRate(.40);
    await tts.speak(selectedAyah!['text']);
  }

  @override void dispose() { speech.stop(); tts.stop(); tts.shutdown(); super.dispose(); }

  @override Widget build(BuildContext context) {
    final ayah = selectedAyah;
    return Scaffold(
      appBar: AppBar(title: const Text('تلاوت چیک کریں'), centerTitle: true),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Card(child: ListTile(leading: const Icon(Icons.menu_book, color: green), title: Text(selectedSurah == null ? 'آیت منتخب کریں' : 'سورہ ${selectedSurah!['number']}: ${selectedSurah!['name']}'), subtitle: Text(ayah == null ? 'اپنی تلاوت کی مشق کے لیے آیت منتخب کریں' : 'آیت ${ayah['number']}'), trailing: const Icon(Icons.chevron_right), onTap: chooseAyah)),
        if (ayah != null) ...[
          const SizedBox(height: 12),
          Card(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)), child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
            Text(ayah['text'], textDirection: TextDirection.rtl, textAlign: TextAlign.center, style: const TextStyle(fontSize: 29, height: 2)),
            const SizedBox(height: 18),
            OutlinedButton.icon(onPressed: hearCorrect, icon: const Icon(Icons.volume_up), label: const Text('صحیح تلاوت سنیں')),
          ]))),
          const SizedBox(height: 12),
          Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
            const Text('اپنی تلاوت چیک کریں', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('آیت کو واضح آواز میں پڑھیں۔ ایپ ممکنہ لفظی فرق تلاش کرے گی۔ یہ تجوید یا مخارج کی قطعی تصدیق نہیں ہے۔', textAlign: TextAlign.center, textDirection: TextDirection.rtl),
            const SizedBox(height: 14),
            FilledButton.icon(onPressed: listening ? stopAndCheck : startListening, icon: Icon(listening ? Icons.stop : Icons.mic), label: Text(listening ? 'تلاوت مکمل کریں' : 'تلاوت شروع کریں')),
            if (recognized.isNotEmpty) ...[const SizedBox(height: 14), const Text('Speech Recognition نے یہ الفاظ سنے:', style: TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 6), Text(recognized, textDirection: TextDirection.rtl, textAlign: TextAlign.center)],
          ]))),
          if (!checking && wordChecks.isNotEmpty) ...[
            const SizedBox(height: 12),
            Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
              Text('لفظی مماثلت: ${(confidence * 100).round()}%', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: green)),
              const SizedBox(height: 8), LinearProgressIndicator(value: confidence, minHeight: 10),
              const SizedBox(height: 14),
              Wrap(spacing: 6, runSpacing: 6, alignment: WrapAlignment.center, children: [for (final w in wordChecks) _wordChip(w)]),
              const SizedBox(height: 14),
              const Text('اہم: یہ نتیجہ صرف ابتدائی لفظی موازنہ ہے۔ اسے قرآن کی تلاوت، مخارج یا تجوید کے درست ہونے کی حتمی سند نہ سمجھیں۔ سیکھنے کے لیے مستند قاری/استاد سے بھی تصدیق کریں۔', textDirection: TextDirection.rtl, textAlign: TextAlign.center, style: TextStyle(color: Colors.black54, height: 1.5)),
            ]))),
          ],
        ] else const SizedBox(height: 80),
      ]),
    );
  }

  Widget _wordChip(_WordCheck w) {
    final icon = w.status == _WordStatus.match ? Icons.check_circle : w.status == _WordStatus.missing ? Icons.remove_circle : Icons.error;
    final label = w.status == _WordStatus.match ? w.expected : w.status == _WordStatus.missing ? '${w.expected} (نہیں سنا گیا)' : '${w.expected} ← ${w.heard}';
    return Chip(avatar: Icon(icon, size: 18), label: Text(label, textDirection: TextDirection.rtl));
  }
}

enum _WordStatus { match, missing, substitution }
class _WordCheck {
  final String expected;
  final String heard;
  final _WordStatus status;
  _WordCheck(this.expected, this.heard, this.status);
}

List<String> _arabicWords(dynamic text) {
  final s = text.toString()
      .replaceAll(RegExp(r'[\u064B-\u065F\u0670\u06D6-\u06ED]'), '')
      .replaceAll(RegExp(r'[۞۩،؛؟,.!?]'), ' ')
      .replaceAll('ـ', '')
      .replaceAll('ٱ', 'ا')
      .replaceAll('أ', 'ا').replaceAll('إ', 'ا').replaceAll('آ', 'ا')
      .replaceAll('ى', 'ي').replaceAll('ؤ', 'و').replaceAll('ئ', 'ي')
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();
  return s.isEmpty ? [] : s.split(' ');
}

List<_WordCheck> _alignWords(List<String> expected, List<String> heard) {
  final n = expected.length, m = heard.length;
  final dp = List.generate(n + 1, (_) => List<int>.filled(m + 1, 0));
  for (var i = 0; i <= n; i++) dp[i][0] = i;
  for (var j = 0; j <= m; j++) dp[0][j] = j;
  for (var i = 1; i <= n; i++) {
    for (var j = 1; j <= m; j++) {
      final cost = expected[i - 1] == heard[j - 1] ? 0 : 1;
      dp[i][j] = [dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost].reduce((a,b) => a < b ? a : b);
    }
  }
  final out = <_WordCheck>[];
  var i = n, j = m;
  while (i > 0 || j > 0) {
    if (i > 0 && j > 0 && expected[i - 1] == heard[j - 1]) {
      out.add(_WordCheck(expected[i - 1], heard[j - 1], _WordStatus.match)); i--; j--;
    } else if (i > 0 && j > 0 && dp[i][j] == dp[i - 1][j - 1] + 1) {
      out.add(_WordCheck(expected[i - 1], heard[j - 1], _WordStatus.substitution)); i--; j--;
    } else if (i > 0 && dp[i][j] == dp[i - 1][j] + 1) {
      out.add(_WordCheck(expected[i - 1], '', _WordStatus.missing)); i--;
    } else {
      j--;
    }
  }
  return out.reversed.toList();
}


class TilawatPage extends StatefulWidget {
  final SharedPreferences prefs; final Future<QuranData> future;
  const TilawatPage({super.key, required this.prefs, required this.future});
  @override State<TilawatPage> createState() => _TilawatPageState();
}
class _TilawatPageState extends State<TilawatPage> {
  final audio = OfflineAudioManager.instance;
  int? selected; bool loading = false;
  Future<void> download(int n) async {
    setState(() => loading = true);
    try { await audio.download(n); if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Audio Offline محفوظ ہو گئی ہے۔'))); setState(() {}); }
    catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Download failed: $e'))); }
    finally { if (mounted) setState(() => loading = false); }
  }
  Future<void> play(int n) async {
    try { await audio.playSurah(n); setState(() => selected = n); }
    catch (e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e'))); }
  }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('تلاوت سنیں'), centerTitle: true),
    body: FutureBuilder<QuranData>(future: widget.future, builder: (context, snap) {
      if (!snap.hasData) return const Center(child: CircularProgressIndicator());
      final surahs = snap.data!.surahs;
      return Column(children: [
        Container(margin: const EdgeInsets.all(12), padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: green.withOpacity(.10), borderRadius: BorderRadius.circular(18)), child: const Row(children: [Icon(Icons.download_for_offline, color: green), SizedBox(width: 10), Expanded(child: Text('پہلے Download کریں، پھر Audio Internet کے بغیر چل سکتی ہے۔'))])),
        Expanded(child: ListView.builder(itemCount: surahs.length, itemBuilder: (_, i) {
          final s = surahs[i]; final n = s['number'] as int;
          return FutureBuilder<bool>(future: audio.isDownloaded(n), builder: (_, dl) {
            final saved = dl.data == true;
            return Card(margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4), child: ListTile(
              leading: CircleAvatar(backgroundColor: green, foregroundColor: Colors.white, child: Text('$n')),
              title: Text(s['name'], textDirection: TextDirection.rtl, textAlign: TextAlign.right, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
              subtitle: Text(saved ? 'Offline محفوظ • ${s['ayahCount']} آیات' : 'Download for Offline • ${s['ayahCount']} آیات', textAlign: TextAlign.right),
              trailing: IconButton(onPressed: loading ? null : () => saved ? play(n) : download(n), icon: Icon(saved ? Icons.play_circle : Icons.download_for_offline, color: green, size: 32)),
            ));
          });
        })),
        StreamBuilder<PlayerState>(stream: audio.player.playerStateStream, builder: (_, state) {
          if (selected == null) return const SizedBox.shrink();
          final playing = state.data?.playing == true;
          return SafeArea(child: Container(color: Colors.white, padding: const EdgeInsets.all(8), child: Row(children: [Expanded(child: Text('سورہ $selected', style: const TextStyle(fontWeight: FontWeight.bold))), IconButton(onPressed: playing ? audio.player.pause : () => play(selected!), icon: Icon(playing ? Icons.pause : Icons.play_arrow, color: green)), IconButton(onPressed: audio.player.stop, icon: const Icon(Icons.stop))])));
        }),
      ]);
    }),
  );
}

class BookmarksPage extends StatefulWidget { final SharedPreferences prefs; final Future<QuranData> future; const BookmarksPage({super.key,required this.prefs,required this.future}); @override State<BookmarksPage> createState()=>_BookmarksPageState(); }
class _BookmarksPageState extends State<BookmarksPage>{
  @override Widget build(BuildContext context)=>FutureBuilder<QuranData>(future:widget.future,builder:(context,snap){if(!snap.hasData)return const Scaffold(body:Center(child:CircularProgressIndicator())); final keys=widget.prefs.getStringList('bookmarks')??[]; final rows=<Map<String,dynamic>>[]; for(final s in snap.data!.surahs){for(final a in (s['ayahs'] as List)){final k='${s['number']}:${a['number']}';if(keys.contains(k))rows.add({'key':k,'surah':s,'ayah':a});}} return Scaffold(appBar:AppBar(title:const Text('محفوظ آیات')),body:rows.isEmpty?const Center(child:Text('ابھی کوئی آیت محفوظ نہیں کی گئی')):ListView.builder(padding:const EdgeInsets.all(12),itemCount:rows.length,itemBuilder:(_,i){final r=rows[i];return Card(margin:const EdgeInsets.only(bottom:10),child:ListTile(title:Text(r['ayah']['text'],textDirection:TextDirection.rtl,textAlign:TextAlign.right,maxLines:3,overflow:TextOverflow.ellipsis),subtitle:Text('سورہ ${r['surah']['name']} • آیت ${r['ayah']['number']}'),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>SurahPage(prefs:widget.prefs,surah:r['surah']))));}));});
}

class ProgressPage extends StatefulWidget { final SharedPreferences prefs; final bool embedded; const ProgressPage({super.key,required this.prefs,this.embedded=false}); @override State<ProgressPage> createState()=>_ProgressPageState(); }
class _ProgressPageState extends State<ProgressPage>{ @override Widget build(BuildContext context){ final surah=widget.prefs.getInt('last_surah')??0; final bookmarks=(widget.prefs.getStringList('bookmarks')??[]).length; final pct=(surah/114).clamp(0.0,1.0); final body=ListView(padding:const EdgeInsets.all(16),children:[_stat('Quran Progress',pct,'$surah / 114 Surahs'),_stat('Saved Ayahs',bookmarks/100,'$bookmarks saved'),Card(child:ListTile(leading:const Icon(Icons.cloud_off,color:green),title:const Text('Offline Quran'),subtitle:const Text('Arabic Quran text is stored inside the app.'))),const SizedBox(height:12),OutlinedButton.icon(onPressed:()async{await widget.prefs.remove('last_surah');await widget.prefs.remove('last_ayah');await widget.prefs.remove('bookmarks');setState((){});},icon:const Icon(Icons.restart_alt),label:const Text('Reset Progress'))]); if(widget.embedded)return Scaffold(body:body);return Scaffold(appBar:AppBar(title:const Text('میری پیش رفت')),body:body); }
Widget _stat(String t,double v,String s)=>Card(margin:const EdgeInsets.only(bottom:12),child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(t,style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold)),const SizedBox(height:10),LinearProgressIndicator(value:v.clamp(0,1),minHeight:10,color:green,backgroundColor:green.withOpacity(.12)),const SizedBox(height:7),Text(s)])));
}

class SettingsPage extends StatefulWidget { final SharedPreferences prefs; final bool embedded; const SettingsPage({super.key,required this.prefs,this.embedded=false}); @override State<SettingsPage> createState()=>_SettingsPageState(); }
class _SettingsPageState extends State<SettingsPage>{ bool dark=false; @override void initState(){super.initState();dark=widget.prefs.getBool('dark')??false;} @override Widget build(BuildContext context){final body=ListView(padding:const EdgeInsets.all(16),children:[Card(child:SwitchListTile(title:const Text('Dark Mode'),value:dark,onChanged:(v)async{setState(()=>dark=v);await widget.prefs.setBool('dark',v);},secondary:const Icon(Icons.dark_mode))),Card(child:ListTile(leading:const Icon(Icons.privacy_tip),title:const Text('Privacy Policy'),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const PrivacyPage())))),Card(child:ListTile(leading:const Icon(Icons.info_outline),title:const Text('About Quran Seekho'),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const AboutPage()))))]);if(widget.embedded)return Scaffold(body:body);return Scaffold(appBar:AppBar(title:const Text('Settings')),body:body);}}
class PrivacyPage extends StatelessWidget{const PrivacyPage({super.key});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Privacy Policy')),body:const SingleChildScrollView(padding:EdgeInsets.all(18),child:Text('Quran Seekho Privacy Policy\n\nThis app stores reading progress and bookmarks locally on your device. The bundled Quran text is read from local app assets and does not require internet access. The app does not require an account for offline Quran reading.\n\nIf future versions add online services, their data practices will be described here before release. You can clear saved progress from the Progress screen or by removing the app data.\n\nLast updated: 22 September 2026',style:TextStyle(fontSize:16,height:1.6))));}
class AboutPage extends StatelessWidget{const AboutPage({super.key});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('About')),body:const Padding(padding:EdgeInsets.all(18),child:Text('Quran Seekho\n\nA simple Quran reading and learning app focused on offline Arabic Quran reading.\n\nThe bundled Quran text should retain its source and license attribution.')));}
class MenuPage extends StatelessWidget{const MenuPage({super.key});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Menu')),body:ListView(children:[ListTile(leading:const Icon(Icons.menu_book),title:const Text('Quran'),onTap:()=>Navigator.pop(c)),ListTile(leading:const Icon(Icons.bookmark),title:const Text('Bookmarks')),ListTile(leading:const Icon(Icons.volunteer_activism),title:const Text('دعائیں / Daily Duas'),onTap:()=>Navigator.push(c, MaterialPageRoute(builder: (_) => const DuasPage()))),ListTile(leading:const Icon(Icons.insights),title:const Text('Progress')),ListTile(leading:const Icon(Icons.settings),title:const Text('Settings'))]));}
