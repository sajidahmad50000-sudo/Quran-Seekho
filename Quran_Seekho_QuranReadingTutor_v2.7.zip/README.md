# Quran Seekho — Offline Quran v2.2

This revision removes the minimal/placeholder reader and provides a usable offline Quran reading flow:

- 114 Surahs and bundled Arabic Uthmani text
- Offline Surah search and reading
- Ayah bookmarks stored locally
- Resume/last-surah state stored locally
- Progress screen based on locally stored reading state and bookmarks
- Reset progress
- Settings, Privacy Policy and About screens
- Green/cream Islamic visual theme
- No network request is used to load Quran text

## Important build note
Flutter bundles files only when they are declared as assets in `pubspec.yaml`; this project declares `assets/quran_uthmani.json`. See Flutter's official asset documentation: https://docs.flutter.dev/ui/assets/assets-and-images

## Offline audio
This revision adds an offline-audio download/player flow. Audio is downloaded into the app's private storage and can then be played without internet. The app does not bundle third-party recitations inside the ZIP; the recording/rightsholder terms must be verified before distribution. The default audio URL is configurable in `OfflineAudioManager.urlFor()`.

## Source attribution
Keep the exact source/license notices that accompany the bundled Quran text before public distribution. Verify the text and licensing requirements against the source release used for your final Play Store build.

## Daily Duas
The app now includes a Daily Duas section with commonly used duas in Arabic, Urdu meaning, and when to read them. This is a curated collection of common daily supplications, not a claim to contain every dua found in all Islamic sources.
