package com.quran.seekho
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity()
