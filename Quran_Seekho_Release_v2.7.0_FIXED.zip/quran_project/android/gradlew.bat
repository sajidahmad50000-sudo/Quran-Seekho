@echo off
powershell -NoProfile -Command "Write-Host 'Use Gradle on Windows'"
