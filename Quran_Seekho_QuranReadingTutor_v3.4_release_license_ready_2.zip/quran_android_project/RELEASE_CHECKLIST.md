# Quran Seekho — Release Checklist

## Licensing
- [x] Tanzil attribution notice added to the project.
- [x] Tanzil license/source links added.
- [x] Audio source and personal/commercial-use limitation documented.
- [ ] Obtain/verify permission for the exact audio recording if the app will be publicly/commercially distributed.
- [ ] Generate and include the exact dependency license report from the final lockfile.

## Build
- [ ] Run `flutter pub get`.
- [ ] Run `flutter analyze` and fix all errors/warnings that matter for release.
- [ ] Run `flutter test` if tests are added.
- [ ] Run `flutter build apk --release`.
- [ ] Prefer `flutter build appbundle --release` for Google Play distribution.
- [ ] Sign the release build with a production keystore.

## Store metadata
- [ ] Final package/application ID.
- [ ] App icon and screenshots.
- [ ] Privacy Policy URL/page.
- [ ] Google Play Data Safety declaration based on the final app behavior.
- [ ] Content/age declaration and category.
- [ ] Final version name/code.

## Functional QA
- [ ] Quran reading and search.
- [ ] Bookmarks.
- [ ] Resume reading.
- [ ] Progress and reset.
- [ ] Menu navigation.
- [ ] Daily Duas/TTS.
- [ ] Audio download, playback, pause, delete and offline playback.
- [ ] Reading Practice microphone permission and error states.
- [ ] Dark mode behavior.
