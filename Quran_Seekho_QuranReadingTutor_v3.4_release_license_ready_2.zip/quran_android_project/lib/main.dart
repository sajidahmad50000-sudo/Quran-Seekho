import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:just_audio/just_audio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'dart:io';

const green = Color(0xFF0B6B4B);
const cream = Color(0xFFF8F2E6);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  runApp(QuranSeekho(prefs: prefs));
}

class QuranSeekho extends StatelessWidget {
  final SharedPreferences prefs;
  const QuranSeekho({super.key, required this.prefs});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Quran Seekho',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: cream,
        colorScheme: ColorScheme.fromSeed(seedColor: green),
        appBarTheme: const AppBarTheme(backgroundColor: green, foregroundColor: Colors.white),
        cardTheme: CardThemeData(color: Colors.white, elevation: 0, margin: EdgeInsets.zero),
      ),
      home: HomePage(prefs: prefs),
    );
  }
}

class QuranData {
  final List<Map<String, dynamic>> surahs;
  QuranData(this.surahs);
  static Future<QuranData> load() async {
    final raw = await rootBundle.loadString('assets/quran_uthmani.json');
    final data = jsonDecode(raw) as Map<String, dynamic>;
    return QuranData((data['surahs'] as List).cast<Map<String, dynamic>>());
  }
}


class OfflineAudioManager {
  static final OfflineAudioManager instance = OfflineAudioManager._();
  OfflineAudioManager._();

  final AudioPlayer player = AudioPlayer();
  int? currentSurah;

  String urlFor(int surah) =>
      'https://download.quranicaudio.com/quran/abdullaah_3awwaad_al-juhaynee/${surah.toString().padLeft(3, '0')}.mp3';

  Future<Directory> _dir() async {
    final base = await getApplicationDocumentsDirectory();
    final dir = Directory('${base.path}/quran_audio');
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  Future<File> localFile(int surah) async {
    final dir = await _dir();
    return File('${dir.path}/${surah.toString().padLeft(3, '0')}.mp3');
  }

  Future<bool> isDownloaded(int surah) async {
    final file = await localFile(surah);
    if (!await file.exists()) return false;
    return (await file.length()) > 0;
  }

  Future<int> localSize(int surah) async {
    final file = await localFile(surah);
    return await file.exists() ? file.length() : 0;
  }

  Future<File> download(int surah, {void Function(int received, int total)? onProgress}) async {
    final file = await localFile(surah);
    if (await isDownloaded(surah)) {
      onProgress?.call(await file.length(), await file.length());
      return file;
    }

    final temp = File('${file.path}.part');
    if (await temp.exists()) await temp.delete();

    final client = http.Client();
    try {
      final request = http.Request('GET', Uri.parse(urlFor(surah)));
      final response = await client.send(request).timeout(const Duration(minutes: 5));
      if (response.statusCode != 200) {
        throw Exception('Audio download failed (${response.statusCode})');
      }

      final total = response.contentLength ?? -1;
      var received = 0;
      final sink = temp.openWrite();
      try {
        await for (final chunk in response.stream) {
          received += chunk.length;
          sink.add(chunk);
          onProgress?.call(received, total);
        }
      } finally {
        await sink.close();
      }

      if (received == 0) throw Exception('Audio file خالی موصول ہوئی۔');
      if (total > 0 && received != total) {
        throw Exception('Audio download مکمل نہیں ہوئی۔ دوبارہ کوشش کریں۔');
      }

      if (await file.exists()) await file.delete();
      await temp.rename(file.path);
      onProgress?.call(received, total > 0 ? total : received);
      return file;
    } finally {
      client.close();
      if (await temp.exists()) await temp.delete();
    }
  }

  Future<void> delete(int surah) async {
    final file = await localFile(surah);
    if (await file.exists()) await file.delete();
    if (currentSurah == surah) {
      await player.stop();
      currentSurah = null;
    }
  }

  Future<void> playSurah(int surah) async {
    final file = await localFile(surah);
    if (!await isDownloaded(surah)) {
      throw Exception('یہ سورہ Offline محفوظ نہیں ہے۔ پہلے Download کریں۔');
    }
    await player.setFilePath(file.path);
    currentSurah = surah;
    await player.play();
  }

  Future<void> dispose() async {
    await player.dispose();
  }
}

class DuaItem {
  final String title, arabic, meaning, when;
  const DuaItem(this.title, this.arabic, this.meaning, this.when);
}

const dailyDuas = <DuaItem>[
  DuaItem('کھانے سے پہلے', 'بِسْمِ اللّٰهِ', 'اللہ کے نام سے شروع کرتا/کرتی ہوں۔', 'کھانا شروع کرتے وقت'),
  DuaItem('کھانے کے بعد', 'الْحَمْدُ لِلّٰهِ الَّذِي أَطْعَمَنِي هَٰذَا وَرَزَقَنِيهِ مِنْ غَيْرِ حَوْلٍ مِنِّي وَلَا قُوَّةٍ', 'تمام تعریفیں اللہ کے لیے ہیں جس نے مجھے یہ کھانا کھلایا اور مجھے عطا کیا، بغیر میری طاقت و قوت کے۔', 'کھانا کھانے کے بعد'),
  DuaItem('سونے سے پہلے', 'بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا', 'اے اللہ! تیرے ہی نام کے ساتھ مرتا اور جیتا ہوں۔', 'سونے سے پہلے'),
  DuaItem('جاگنے کے بعد', 'الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ', 'تمام تعریف اللہ کے لیے ہے جس نے ہمیں موت جیسی نیند کے بعد زندہ کیا اور اسی کی طرف لوٹنا ہے۔', 'نیند سے جاگنے کے بعد'),
  DuaItem('گھر سے نکلتے وقت', 'بِسْمِ اللَّهِ، تَوَكَّلْتُ عَلَى اللَّهِ، لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ', 'اللہ کے نام سے، میں نے اللہ پر بھروسہ کیا، طاقت اور قوت صرف اللہ ہی سے ہے۔', 'گھر سے نکلتے وقت'),
  DuaItem('گھر میں داخل ہوتے وقت', 'بِسْمِ اللَّهِ وَلَجْنَا، وَبِسْمِ اللَّهِ خَرَجْنَا، وَعَلَى اللَّهِ رَبِّنَا تَوَكَّلْنَا', 'اللہ کے نام سے داخل ہوئے، اللہ کے نام سے نکلے اور اپنے رب اللہ پر بھروسہ کیا۔', 'گھر میں داخل ہوتے وقت'),
  DuaItem('بیت الخلاء میں داخل ہوتے وقت', 'اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْخُبُثِ وَالْخَبَائِثِ', 'اے اللہ! میں ناپاک شیاطین سے تیری پناہ مانگتا/مانگتی ہوں۔', 'بیت الخلاء میں داخل ہونے سے پہلے'),
  DuaItem('بیت الخلاء سے نکلتے وقت', 'غُفْرَانَكَ', 'اے اللہ! میں تجھ سے مغفرت طلب کرتا/کرتی ہوں۔', 'بیت الخلاء سے نکلنے کے بعد'),
  DuaItem('وضو کے بعد', 'أَشْهَدُ أَنْ لَا إِلَٰهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، وَأَشْهَدُ أَنَّ مُحَمَّدًا عَبْدُهُ وَرَسُولُهُ', 'میں گواہی دیتا/دیتی ہوں کہ اللہ کے سوا کوئی معبود نہیں، وہ اکیلا ہے، اس کا کوئی شریک نہیں، اور محمد ﷺ اس کے بندے اور رسول ہیں۔', 'وضو مکمل کرنے کے بعد'),
  DuaItem('مسجد میں داخل ہوتے وقت', 'اللَّهُمَّ افْتَحْ لِي أَبْوَابَ رَحْمَتِكَ', 'اے اللہ! میرے لیے اپنی رحمت کے دروازے کھول دے۔', 'مسجد میں داخل ہوتے وقت'),
  DuaItem('مسجد سے نکلتے وقت', 'اللَّهُمَّ إِنِّي أَسْأَلُكَ مِنْ فَضْلِكَ', 'اے اللہ! میں تجھ سے تیرے فضل کا سوال کرتا/کرتی ہوں۔', 'مسجد سے نکلتے وقت'),
  DuaItem('سفر کی دعا', 'سُبْحَانَ الَّذِي سَخَّرَ لَنَا هَٰذَا وَمَا كُنَّا لَهُ مُقْرِنِينَ ۝ وَإِنَّا إِلَىٰ رَبِّنَا لَمُنقَلِبُونَ', 'پاک ہے وہ ذات جس نے اسے ہمارے لیے مسخر کیا، ورنہ ہم اسے قابو میں نہیں لا سکتے تھے، اور ہم اپنے رب کی طرف لوٹنے والے ہیں۔', 'سفر شروع کرتے وقت'),
  DuaItem('علم میں اضافہ', 'رَبِّ زِدْنِي عِلْمًا', 'اے میرے رب! میرے علم میں اضافہ فرما۔', 'علم حاصل کرتے وقت'),
  DuaItem('والدین کے لیے', 'رَبِّ ارْحَمْهُمَا كَمَا رَبَّيَانِي صَغِيرًا', 'اے میرے رب! ان دونوں پر رحم فرما جیسے انہوں نے بچپن میں مجھے پالا۔', 'والدین کے لیے دعا'),
  DuaItem('مغفرت کی دعا', 'رَبِّ اغْفِرْ لِي وَارْحَمْنِي وَأَنْتَ خَيْرُ الرَّاحِمِينَ', 'اے میرے رب! مجھے بخش دے اور مجھ پر رحم فرما، اور تو سب سے بہتر رحم کرنے والا ہے۔', 'مغفرت مانگتے وقت'),
  DuaItem('دنیا و آخرت کی بھلائی', 'رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ', 'اے ہمارے رب! ہمیں دنیا میں بھلائی دے، آخرت میں بھی بھلائی دے اور ہمیں آگ کے عذاب سے بچا۔', 'عمومی دعا'),
  DuaItem('مصیبت کے وقت', 'إِنَّا لِلَّهِ وَإِنَّا إِلَيْهِ رَاجِعُونَ', 'بے شک ہم اللہ ہی کے ہیں اور اسی کی طرف لوٹ کر جانے والے ہیں۔', 'مصیبت یا نقصان کے وقت'),
  DuaItem('بارش کی دعا', 'اللَّهُمَّ صَيِّبًا نَافِعًا', 'اے اللہ! اسے نفع بخش بارش بنا۔', 'بارش کے وقت'),
  DuaItem('بارش کے بعد', 'مُطِرْنَا بِفَضْلِ اللَّهِ وَرَحْمَتِهِ', 'ہم پر اللہ کے فضل اور رحمت سے بارش ہوئی۔', 'بارش کے بعد'),
  DuaItem('مریض کی عیادت', 'أَسْأَلُ اللَّهَ الْعَظِيمَ رَبَّ الْعَرْشِ الْعَظِيمِ أَنْ يَشْفِيَكَ', 'میں عظمت والے اللہ، عرش عظیم کے رب سے دعا کرتا/کرتی ہوں کہ وہ تمہیں شفا دے۔', 'مریض کی عیادت کے وقت'),
  DuaItem('افطار کی دعا', 'ذَهَبَ الظَّمَأُ وَابْتَلَّتِ الْعُرُوقُ وَثَبَتَ الْأَجْرُ إِنْ شَاءَ اللَّهُ', 'پیاس ختم ہوئی، رگیں تر ہوئیں اور ان شاء اللہ اجر ثابت ہوگیا۔', 'روزہ افطار کرتے وقت'),
  DuaItem('چھینک کا جواب', 'يَرْحَمُكَ اللَّهُ', 'اللہ تم پر رحم فرمائے۔', 'چھینکنے والے کے الحمدللہ کہنے پر'),
  DuaItem('چھینک کے بعد', 'الْحَمْدُ لِلَّهِ', 'تمام تعریفیں اللہ کے لیے ہیں۔', 'چھینک آنے کے بعد'),
  DuaItem('دل کے اطمینان کی قرآنی دعا', 'رَبَّنَا لَا تُزِغْ قُلُوبَنَا بَعْدَ إِذْ هَدَيْتَنَا وَهَبْ لَنَا مِنْ لَدُنْكَ رَحْمَةً إِنَّكَ أَنْتَ الْوَهَّابُ', 'اے ہمارے رب! ہدایت دینے کے بعد ہمارے دل ٹیڑھے نہ کر اور ہمیں اپنے پاس سے رحمت عطا فرما۔ بے شک تو بہت عطا کرنے والا ہے۔', 'ہدایت اور ثابت قدمی کے لیے'),
  DuaItem('قرآن سمجھنے اور عمل کی دعا', 'اللَّهُمَّ انْفَعْنِي بِمَا عَلَّمْتَنِي وَعَلِّمْنِي مَا يَنْفَعُنِي وَزِدْنِي عِلْمًا', 'اے اللہ! جو تو نے مجھے سکھایا اس سے مجھے نفع دے، مجھے وہ سکھا جو میرے لیے نفع بخش ہو، اور میرے علم میں اضافہ فرما۔', 'علم اور قرآن سیکھتے وقت'),
];

class DuasPage extends StatefulWidget {
  const DuasPage({super.key});
  @override State<DuasPage> createState() => _DuasPageState();
}

class _DuasPageState extends State<DuasPage> {
  final FlutterTts tts = FlutterTts();
  String query = '';
  bool speaking = false;

  @override
  void initState() {
    super.initState();
    _setupTts();
  }

  Future<void> _setupTts() async {
    try {
      await tts.setLanguage('ar-SA');
      await tts.setSpeechRate(0.42);
      await tts.setPitch(1.0);
      tts.setStartHandler(() { if (mounted) setState(() => speaking = true); });
      tts.setCompletionHandler(() { if (mounted) setState(() => speaking = false); });
      tts.setCancelHandler(() { if (mounted) setState(() => speaking = false); });
      tts.setErrorHandler((_) { if (mounted) setState(() => speaking = false); });
    } catch (_) {}
  }

  Future<void> speak(DuaItem d) async {
    try {
      await tts.stop();
      await tts.setLanguage('ar-SA');
      await tts.speak(d.arabic);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Voice کے لیے فون میں Arabic Text-to-Speech voice انسٹال/فعال کریں۔')),
        );
      }
    }
  }

  Future<void> stopVoice() async {
    await tts.stop();
    if (mounted) setState(() => speaking = false);
  }

  @override
  void dispose() {
    tts.stop();
    tts.shutdown();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final q = query.trim().toLowerCase();
    final filtered = dailyDuas.where((d) {
      if (q.isEmpty) return true;
      return d.title.toLowerCase().contains(q) ||
          d.meaning.toLowerCase().contains(q) ||
          d.when.toLowerCase().contains(q) ||
          d.arabic.contains(query.trim());
    }).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('روزمرہ کی دعائیں'), centerTitle: true),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 6),
          child: TextField(
            textDirection: TextDirection.rtl,
            onChanged: (v) => setState(() => query = v),
            decoration: InputDecoration(
              hintText: 'دعا تلاش کریں... مثلاً کھانا، سفر، سونا',
              prefixIcon: const Icon(Icons.search),
              suffixIcon: query.isEmpty ? null : IconButton(icon: const Icon(Icons.clear), onPressed: () => setState(() => query = '')),
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          child: Row(children: [
            Expanded(child: Text('${filtered.length} دعائیں', textDirection: TextDirection.rtl, textAlign: TextAlign.right, style: const TextStyle(color: Colors.black54))),
            if (speaking) TextButton.icon(onPressed: stopVoice, icon: const Icon(Icons.stop, color: green), label: const Text('آواز بند کریں')),
          ]),
        ),
        Expanded(
          child: filtered.isEmpty
              ? const Center(child: Text('کوئی دعا نہیں ملی'))
              : ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: filtered.length,
                  itemBuilder: (_, i) {
                    final d = filtered[i];
                    return Card(
                      margin: const EdgeInsets.only(bottom: 12),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(20),
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DuaDetailPage(dua: d, tts: tts))),
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                            Row(children: [
                              Expanded(child: Text(d.title, textDirection: TextDirection.rtl, textAlign: TextAlign.right, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold, color: green))),
                              IconButton(onPressed: () => speak(d), tooltip: 'دعا سنیں', icon: const Icon(Icons.volume_up, color: green)),
                            ]),
                            Text(d.when, textDirection: TextDirection.rtl, textAlign: TextAlign.right, style: const TextStyle(color: Colors.black54)),
                            const Divider(height: 22),
                            Text(d.arabic, textDirection: TextDirection.rtl, textAlign: TextAlign.right, style: const TextStyle(fontSize: 25, height: 1.9, fontWeight: FontWeight.w600)),
                            const SizedBox(height: 10),
                            Text(d.meaning, textDirection: TextDirection.rtl, textAlign: TextAlign.right, style: const TextStyle(fontSize: 16, height: 1.7)),
                            const SizedBox(height: 6),
                            const Align(alignment: Alignment.centerLeft, child: Icon(Icons.arrow_forward_ios, size: 15, color: Colors.black38)),
                          ]),
                        ),
                      ),
                    );
                  },
                ),
        ),
      ]),
    );
  }
}

class DuaDetailPage extends StatefulWidget {
  final DuaItem dua;
  final FlutterTts tts;
  const DuaDetailPage({super.key, required this.dua, required this.tts});
  @override State<DuaDetailPage> createState() => _DuaDetailPageState();
}

class _DuaDetailPageState extends State<DuaDetailPage> {
  bool speaking = false;

  Future<void> play() async {
    try {
      await widget.tts.stop();
      await widget.tts.setLanguage('ar-SA');
      await widget.tts.setSpeechRate(0.42);
      widget.tts.setCompletionHandler(() { if (mounted) setState(() => speaking = false); });
      widget.tts.setCancelHandler(() { if (mounted) setState(() => speaking = false); });
      setState(() => speaking = true);
      await widget.tts.speak(widget.dua.arabic);
    } catch (_) {
      if (mounted) {
        setState(() => speaking = false);
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Arabic voice فون کے Text-to-Speech engine پر منحصر ہے۔')));
      }
    }
  }

  Future<void> stop() async {
    await widget.tts.stop();
    if (mounted) setState(() => speaking = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('دعا'), centerTitle: true),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      Card(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)), child: Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Text(widget.dua.title, textDirection: TextDirection.rtl, textAlign: TextAlign.right, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold, color: green)),
        const SizedBox(height: 8),
        Text(widget.dua.when, textDirection: TextDirection.rtl, textAlign: TextAlign.right, style: const TextStyle(color: Colors.black54)),
        const Divider(height: 30),
        Text(widget.dua.arabic, textDirection: TextDirection.rtl, textAlign: TextAlign.center, style: const TextStyle(fontSize: 31, height: 2.0, fontWeight: FontWeight.w600)),
        const SizedBox(height: 18),
        Text(widget.dua.meaning, textDirection: TextDirection.rtl, textAlign: TextAlign.right, style: const TextStyle(fontSize: 18, height: 1.8)),
        const SizedBox(height: 22),
        FilledButton.icon(onPressed: speaking ? stop : play, icon: Icon(speaking ? Icons.stop : Icons.volume_up), label: Text(speaking ? 'آواز بند کریں' : 'دعا کی آواز سنیں')),
      ])),
      const SizedBox(height: 14),
      const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('نوٹ: آواز فون کے Arabic Text-to-Speech engine سے چلتی ہے۔ اگر Arabic voice فون میں موجود نہ ہو تو اسے Text-to-Speech settings سے انسٹال کریں۔', textDirection: TextDirection.rtl, textAlign: TextAlign.right, style: TextStyle(height: 1.6)))),
    ]),
  );
}

class HomePage extends StatefulWidget {
  final SharedPreferences prefs;
  const HomePage({super.key, required this.prefs});
  @override State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  late Future<QuranData> future;
  @override void initState() { super.initState(); future = QuranData.load(); }

  void openQuran() => Navigator.push(context, MaterialPageRoute(builder: (_) => QuranPage(prefs: widget.prefs, future: future)));
  void openProgress() => Navigator.push(context, MaterialPageRoute(builder: (_) => ProgressPage(prefs: widget.prefs)));

  @override Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('قرآن سیکھو', style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
        leading: IconButton(icon: const Icon(Icons.menu), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => MenuPage(prefs: widget.prefs, future: future)))),
        actions: [IconButton(icon: const Icon(Icons.bookmark_outline), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => BookmarksPage(prefs: widget.prefs, future: future))))],
      ),
      body: IndexedStack(index: tab, children: [
        _homeBody(context),
        QuranPage(prefs: widget.prefs, future: future, embedded: true),
        ProgressPage(prefs: widget.prefs, embedded: true),
        SettingsPage(prefs: widget.prefs, embedded: true),
      ]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'Quran'),
          NavigationDestination(icon: Icon(Icons.insights_outlined), selectedIcon: Icon(Icons.insights), label: 'Progress'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'Settings'),
        ],
      ),
    );
  }

  Widget _homeBody(BuildContext context) {
    final lastSurah = widget.prefs.getInt('last_surah');
    final lastAyah = widget.prefs.getInt('last_ayah');
    return ListView(padding: const EdgeInsets.all(16), children: [
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(color: green, borderRadius: BorderRadius.circular(24)),
        child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيْمِ', textDirection: TextDirection.rtl, style: TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.bold)),
          SizedBox(height: 8), Text('قرآن پاک پڑھیں، سیکھیں اور سمجھیں', style: TextStyle(color: Colors.white70, fontSize: 15)),
        ]),
      ),
      const SizedBox(height: 18),
      if (lastSurah != null) _resumeCard(lastSurah, lastAyah ?? 1),
      const SizedBox(height: 14),
      GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.25, children: [
        _tile(Icons.menu_book, 'قرآن پڑھیں', 'Read Quran', openQuran),
        _tile(Icons.headphones, 'تلاوت سنیں', 'Offline Tilawat', () => Navigator.push(context, MaterialPageRoute(builder: (_) => TilawatPage(prefs: widget.prefs, future: future)))),
        _tile(Icons.bookmark, 'محفوظ آیات', 'Bookmarks', () => Navigator.push(context, MaterialPageRoute(builder: (_) => BookmarksPage(prefs: widget.prefs, future: future)))),
        _tile(Icons.volunteer_activism, 'دعائیں', 'Daily Duas', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DuasPage()))),
        _tile(Icons.record_voice_over, 'تلاوت چیک کریں', 'Reading Practice', () => Navigator.push(context, MaterialPageRoute(builder: (_) => ReadingPracticePage(prefs: widget.prefs, future: future)))),
        _tile(Icons.insights, 'میری پیش رفت', 'Progress', openProgress),
        _tile(Icons.settings, 'سیٹنگز', 'Settings', () => setState(() => tab = 3)),
      ]),
      const SizedBox(height: 18),
      Card(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)), child: const Padding(padding: EdgeInsets.all(18), child: Row(children: [Icon(Icons.cloud_off, color: green, size: 30), SizedBox(width: 12), Expanded(child: Text('Quran text مکمل طور پر Offline ہے۔ انٹرنیٹ کی ضرورت نہیں۔'))]))),
      const SizedBox(height: 18),
      Card(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)), child: const Padding(padding: EdgeInsets.all(18), child: Text('یہ ایپ قرآن پڑھنے اور سیکھنے میں مدد کے لیے بنائی گئی ہے۔'))),
    ]);
  }

  Widget _resumeCard(int surah, int ayah) => Card(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)), child: ListTile(leading: const CircleAvatar(backgroundColor: green, child: Icon(Icons.play_arrow, color: Colors.white)), title: const Text('جہاں چھوڑا تھا وہاں سے پڑھیں'), subtitle: Text('سورہ $surah • آیت $ayah'), onTap: () async { final d = await future; final s = d.surahs.firstWhere((x) => x['number'] == surah); if (!mounted) return; Navigator.push(context, MaterialPageRoute(builder: (_) => SurahPage(prefs: widget.prefs, surah: s, initialAyah: ayah))); }));

  Widget _tile(IconData icon, String title, String subtitle, VoidCallback onTap) => Card(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)), child: InkWell(borderRadius: BorderRadius.circular(22), onTap: onTap, child: Padding(padding: const EdgeInsets.all(14), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(icon, color: green, size: 34), const SizedBox(height: 8), Text(title, textDirection: TextDirection.rtl, textAlign: TextAlign.center, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), const SizedBox(height: 3), Text(subtitle, style: const TextStyle(color: Colors.black54))])));
}

class QuranPage extends StatefulWidget {
  final SharedPreferences prefs; final Future<QuranData> future; final bool embedded;
  const QuranPage({super.key, required this.prefs, required this.future, this.embedded = false});
  @override State<QuranPage> createState() => _QuranPageState();
}
class _QuranPageState extends State<QuranPage> {
  String query = '';
  @override Widget build(BuildContext context) {
    return FutureBuilder<QuranData>(future: widget.future, builder: (context, snap) {
      if (!snap.hasData) return const Center(child: CircularProgressIndicator());
      final all = snap.data!.surahs;
      final list = all.where((s) => query.isEmpty || s['name'].toString().contains(query) || s['number'].toString() == query).toList();
      final body = Column(children: [Padding(padding: const EdgeInsets.fromLTRB(14, 14, 14, 8), child: TextField(textDirection: TextDirection.rtl, onChanged: (v) => setState(() => query = v.trim()), decoration: InputDecoration(hintText: 'سورہ تلاش کریں', prefixIcon: const Icon(Icons.search), filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none)))), Expanded(child: ListView.builder(itemCount: list.length, itemBuilder: (_, i) { final s = list[i]; return Card(margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 5), child: ListTile(onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SurahPage(prefs: widget.prefs, surah: s))), leading: CircleAvatar(backgroundColor: green, foregroundColor: Colors.white, child: Text('${s['number']}')), title: Text(s['name'], textDirection: TextDirection.rtl, textAlign: TextAlign.right, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)), subtitle: Text('${s['ayahCount']} آیات', textAlign: TextAlign.right), trailing: const Icon(Icons.chevron_right, color: green))); }))]);
      if (widget.embedded) return Scaffold(body: body); return Scaffold(appBar: AppBar(title: const Text('قرآن پاک')), body: body);
    });
  }
}

class SurahPage extends StatefulWidget {
  final SharedPreferences prefs; final Map<String,dynamic> surah; final int initialAyah;
  const SurahPage({super.key, required this.prefs, required this.surah, this.initialAyah = 1});
  @override State<SurahPage> createState() => _SurahPageState();
}
class _SurahPageState extends State<SurahPage> {
  late Set<String> bookmarks;
  final Map<int, GlobalKey> _ayahKeys = {};
  final ScrollController _scrollController = ScrollController();
  int? _currentAyah;

  @override
  void initState() {
    super.initState();
    bookmarks = widget.prefs.getStringList('bookmarks')?.toSet() ?? {};
    _currentAyah = widget.initialAyah;
    final opened = widget.prefs.getStringList('opened_surahs')?.toSet() ?? <String>{};
    opened.add('${widget.surah['number']}');
    widget.prefs.setStringList('opened_surahs', opened.toList());
    WidgetsBinding.instance.addPostFrameCallback((_) => _resumeToAyah());
  }

  Future<void> _resumeToAyah() async {
    if (widget.initialAyah <= 1 || !_scrollController.hasClients) return;
    final ayahs = (widget.surah['ayahs'] as List).cast<Map<String,dynamic>>();
    final index = ayahs.indexWhere((a) => a['number'] == widget.initialAyah);
    if (index < 0) return;
    // First move near the target so its lazily-built card gets a context.
    final estimated = (index * 150.0).clamp(0.0, _scrollController.position.maxScrollExtent);
    await _scrollController.animateTo(estimated, duration: const Duration(milliseconds: 350), curve: Curves.easeOut);
    await WidgetsBinding.instance.endOfFrame;
    final key = _ayahKeys[widget.initialAyah];
    if (key?.currentContext != null) {
      await Scrollable.ensureVisible(key!.currentContext!, duration: const Duration(milliseconds: 450), curve: Curves.easeInOut, alignment: 0.12);
    }
  }

  Future<void> _savePosition(int ayah) async {
    _currentAyah = ayah;
    await widget.prefs.setInt('last_surah', widget.surah['number'] as int);
    await widget.prefs.setInt('last_ayah', ayah);
    if (mounted) setState(() {});
  }

  Future<void> toggle(String key) async {
    setState(() { if (!bookmarks.add(key)) bookmarks.remove(key); });
    await widget.prefs.setStringList('bookmarks', bookmarks.toList());
  }

  @override
  Widget build(BuildContext context) {
    final ayahs = (widget.surah['ayahs'] as List).cast<Map<String,dynamic>>();
    for (final a in ayahs) {
      final n = a['number'] as int;
      _ayahKeys.putIfAbsent(n, () => GlobalKey());
    }
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.surah['name']),
        centerTitle: true,
        actions: [
          if (_currentAyah != null)
            Center(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 10), child: Text('آیت $_currentAyah', style: const TextStyle(fontSize: 13)))),
        ],
      ),
      body: ListView.builder(
        controller: _scrollController,
        padding: const EdgeInsets.all(12),
        itemCount: ayahs.length,
        itemBuilder: (_, i) {
          final a = ayahs[i];
          final ayahNumber = a['number'] as int;
          final key = '${widget.surah['number']}:$ayahNumber';
          final saved = bookmarks.contains(key);
          final isCurrent = _currentAyah == ayahNumber;
          return Card(
            key: _ayahKeys[ayahNumber],
            margin: const EdgeInsets.only(bottom: 10),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
            child: InkWell(
              borderRadius: BorderRadius.circular(18),
              onTap: () => _savePosition(ayahNumber),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(18,18,18,10),
                child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                  Row(children: [
                    if (isCurrent) const Icon(Icons.play_arrow, color: green, size: 20),
                    const Spacer(),
                    Text('آیت $ayahNumber', textDirection: TextDirection.rtl, style: const TextStyle(color: green, fontWeight: FontWeight.bold)),
                  ]),
                  Text(a['text'], textDirection: TextDirection.rtl, textAlign: TextAlign.right, style: const TextStyle(fontSize:28,height:1.9)),
                  const SizedBox(height:8),
                  Row(children:[
                    IconButton(onPressed:()=>toggle(key), icon:Icon(saved?Icons.bookmark:Icons.bookmark_outline,color:green)),
                    IconButton(tooltip:'تلاوت چیک کریں',onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ReadingPracticePage(prefs:widget.prefs, future:Future.value(QuranData([widget.surah])), initialSurahNumber:widget.surah['number'] as int, initialAyahNumber:ayahNumber))), icon:const Icon(Icons.record_voice_over,color:green)),
                    const Spacer(),
                    if (isCurrent) const Text('آپ یہاں تھے', style: TextStyle(color: green, fontSize: 12)),
                  ]),
                ]),
              ),
            ),
          );
        },
      ),
    );
  }

  @override
  void dispose() {
    _scrollController.dispose();
    widget.prefs.setInt('last_surah', widget.surah['number'] as int);
    if (_currentAyah != null) widget.prefs.setInt('last_ayah', _currentAyah!);
    super.dispose();
  }
}


String _normalizeArabic(String value) {
  var s = value.replaceAll(RegExp(r'[\u064B-\u065F\u0670\u06D6-\u06ED]'), '');
  s = s.replaceAll('ٱ', 'ا').replaceAll('أ', 'ا').replaceAll('إ', 'ا').replaceAll('آ', 'ا');
  s = s.replaceAll('ى', 'ي').replaceAll('ؤ', 'و').replaceAll('ئ', 'ي');
  s = s.replaceAll(RegExp(r'[۝۞،؛,.!?]'), ' ');
  return s.replaceAll(RegExp(r'\s+'), ' ').trim();
}

List<String> _arabicWords(String text) => _normalizeArabic(text).split(' ').where((x) => x.isNotEmpty).toList();

class ReadingPracticePage extends StatefulWidget {
  final SharedPreferences prefs;
  final Future<QuranData> future;
  final int? initialSurahNumber;
  final int? initialAyahNumber;
  const ReadingPracticePage({super.key, required this.prefs, required this.future, this.initialSurahNumber, this.initialAyahNumber});
  @override State<ReadingPracticePage> createState() => _ReadingPracticePageState();
}

class _ReadingPracticePageState extends State<ReadingPracticePage> {
  final stt.SpeechToText speech = stt.SpeechToText();
  final FlutterTts tts = FlutterTts();
  bool ready = false, listening = false, checking = false;
  String recognized = '';
  String? recognitionLocale;
  String? speechError;
  Map<String, dynamic>? selectedSurah;
  Map<String, dynamic>? selectedAyah;
  List<_WordCheck> wordChecks = [];
  double score = 0;
  int matchedCount = 0;
  int missingCount = 0;
  int substitutionCount = 0;
  int extraCount = 0;
  DateTime? checkedAt;

  @override void initState() { super.initState(); _init(); }

  Future<void> _init() async {
    try {
      ready = await speech.initialize(
        onStatus: (status) {
          if (!mounted) return;
          setState(() {
            listening = status == 'listening';
            if (!listening && checking && recognized.isNotEmpty) checking = false;
          });
        },
        onError: (error) {
          if (!mounted) return;
          setState(() {
            listening = false;
            checking = false;
            speechError = error.errorMsg;
          });
        },
      );
      final locales = await speech.locales();
      final arabic = locales.where((l) => l.localeId.toLowerCase().startsWith('ar')).toList();
      recognitionLocale = arabic.isNotEmpty ? arabic.first.localeId : 'ar-SA';
    } catch (e) {
      ready = false;
      recognitionLocale = 'ar-SA';
      speechError = 'Microphone/Speech Recognition دستیاب نہیں۔';
    }

    final data = await widget.future;
    if (!mounted) return;
    setState(() {
      if (widget.initialSurahNumber != null) {
        selectedSurah = data.surahs.firstWhere((s) => s['number'] == widget.initialSurahNumber);
      }
      if (selectedSurah != null && widget.initialAyahNumber != null) {
        selectedAyah = (selectedSurah!['ayahs'] as List).cast<Map<String,dynamic>>().firstWhere((a) => a['number'] == widget.initialAyahNumber);
      }
    });
  }

  Future<void> chooseAyah() async {
    final data = await widget.future;
    if (!mounted) return;
    await showModalBottomSheet(context: context, isScrollControlled: true, builder: (_) => SafeArea(child: SizedBox(
      height: MediaQuery.of(context).size.height * .78,
      child: ListView.builder(itemCount: data.surahs.length, itemBuilder: (_, i) {
        final s = data.surahs[i];
        return ExpansionTile(
          title: Text(s['name'], textDirection: TextDirection.rtl, textAlign: TextAlign.right),
          subtitle: Text('${s['ayahCount']} آیات'),
          children: [for (final a in (s['ayahs'] as List).cast<Map<String,dynamic>>())
            ListTile(
              title: Text('آیت ${a['number']}: ${a['text']}', textDirection: TextDirection.rtl, textAlign: TextAlign.right, maxLines: 2, overflow: TextOverflow.ellipsis),
              onTap: () { setState(() { selectedSurah = s; selectedAyah = a; _resetCheck(); }); Navigator.pop(context); },
            )],
        );
      }),
    )));
  }

  void _resetCheck() {
    recognized = '';
    wordChecks = [];
    score = 0;
    matchedCount = 0;
    missingCount = 0;
    substitutionCount = 0;
    extraCount = 0;
    checking = false;
    speechError = null;
    checkedAt = null;
  }

  Future<void> startListening() async {
    if (!ready) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Speech Recognition دستیاب نہیں۔ فون کی Microphone permission اور Arabic speech service چیک کریں۔')));
      return;
    }
    if (selectedAyah == null) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('پہلے آیت منتخب کریں۔')));
      return;
    }
    await speech.stop();
    setState(() { _resetCheck(); checking = true; listening = true; });
    try {
      await speech.listen(
        localeId: recognitionLocale ?? 'ar-SA',
        listenMode: stt.ListenMode.dictation,
        partialResults: true,
        cancelOnError: false,
        listenFor: const Duration(minutes: 2),
        pauseFor: const Duration(seconds: 4),
        onResult: (r) {
          if (!mounted) return;
          setState(() => recognized = r.recognizedWords);
          if (r.finalResult && listening) stopAndCheck();
        },
      );
    } catch (e) {
      if (mounted) setState(() { listening = false; checking = false; speechError = 'Speech Recognition شروع نہیں ہو سکی۔'; });
    }
  }

  Future<void> stopAndCheck() async {
    if (!checking && !listening) return;
    await speech.stop();
    if (selectedAyah == null) return;
    final expected = _arabicWords(selectedAyah!['text']);
    final heard = _arabicWords(recognized);
    final alignment = _alignWordsDetailed(expected, heard);
    final matched = alignment.items.where((x) => x.status == _WordStatus.match).length;
    final missing = alignment.items.where((x) => x.status == _WordStatus.missing).length;
    final substitutions = alignment.items.where((x) => x.status == _WordStatus.substitution).length;
    final scoreValue = expected.isEmpty ? 0.0 : (matched / expected.length).clamp(0.0, 1.0);
    if (!mounted) return;
    setState(() {
      listening = false;
      checking = false;
      wordChecks = alignment.items;
      matchedCount = matched;
      missingCount = missing;
      substitutionCount = substitutions;
      extraCount = alignment.extraWords.length;
      score = scoreValue;
      checkedAt = DateTime.now();
      speechError = heard.isEmpty ? 'آواز واضح طور پر recognize نہیں ہوئی۔ دوبارہ کوشش کریں۔' : null;
    });
    if (heard.isNotEmpty) await _savePractice(scoreValue);
  }

  Future<void> _savePractice(double value) async {
    final s = selectedSurah?['number'];
    final a = selectedAyah?['number'];
    if (s == null || a == null) return;
    final history = widget.prefs.getStringList('practice_history') ?? <String>[];
    final entry = jsonEncode({'surah': s, 'ayah': a, 'score': value, 'time': DateTime.now().toIso8601String()});
    history.insert(0, entry);
    if (history.length > 50) history.removeRange(50, history.length);
    await widget.prefs.setStringList('practice_history', history);
  }

  Future<void> hearCorrect() async {
    if (selectedAyah == null) return;
    await tts.stop();
    await tts.setLanguage('ar-SA');
    await tts.setSpeechRate(.40);
    await tts.speak(selectedAyah!['text']);
  }

  @override void dispose() { speech.stop(); tts.stop(); tts.shutdown(); super.dispose(); }

  @override Widget build(BuildContext context) {
    final ayah = selectedAyah;
    final percent = (score * 100).round();
    return Scaffold(
      appBar: AppBar(title: const Text('تلاوت چیک کریں'), centerTitle: true),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Card(child: ListTile(leading: const Icon(Icons.menu_book, color: green), title: Text(selectedSurah == null ? 'آیت منتخب کریں' : 'سورہ ${selectedSurah!['number']}: ${selectedSurah!['name']}'), subtitle: Text(ayah == null ? 'مشق کے لیے آیت منتخب کریں' : 'آیت ${ayah['number']}'), trailing: const Icon(Icons.chevron_right), onTap: chooseAyah)),
        if (ayah != null) ...[
          const SizedBox(height: 12),
          Card(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)), child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
            Text(ayah['text'], textDirection: TextDirection.rtl, textAlign: TextAlign.center, style: const TextStyle(fontSize: 29, height: 2)),
            const SizedBox(height: 18),
            OutlinedButton.icon(onPressed: hearCorrect, icon: const Icon(Icons.volume_up), label: const Text('صحیح تلاوت سنیں')),
          ]))),
          const SizedBox(height: 12),
          Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
            const Text('اپنی تلاوت چیک کریں', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('آیت کو مسلسل پڑھیں۔ ایپ Arabic Speech Recognition سے سنے گئے الفاظ کو آیت کے اصل الفاظ سے align کرکے نتیجہ دیتی ہے۔', textAlign: TextAlign.center, textDirection: TextDirection.rtl),
            const SizedBox(height: 14),
            FilledButton.icon(onPressed: listening ? stopAndCheck : startListening, icon: Icon(listening ? Icons.stop : Icons.mic), label: Text(listening ? 'تلاوت مکمل کریں' : 'تلاوت شروع کریں')),
            if (recognized.isNotEmpty) ...[const SizedBox(height: 14), const Text('Recognized:', style: TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 6), Text(recognized, textDirection: TextDirection.rtl, textAlign: TextAlign.center)],
            if (speechError != null) ...[const SizedBox(height: 10), Text(speechError!, textAlign: TextAlign.center, style: const TextStyle(color: Colors.red))],
          ]))),
          if (!checking && (wordChecks.isNotEmpty || checkedAt != null)) ...[
            const SizedBox(height: 12),
            Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
              Text('تلاوت کا نتیجہ: $percent%', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: green)),
              const SizedBox(height: 8), LinearProgressIndicator(value: score, minHeight: 10),
              const SizedBox(height: 14),
              Wrap(alignment: WrapAlignment.center, spacing: 8, runSpacing: 8, children: [
                _statChip('درست', matchedCount, Icons.check_circle),
                _statChip('چھوٹے', missingCount, Icons.remove_circle),
                _statChip('بدلے', substitutionCount, Icons.sync_problem),
                _statChip('اضافی', extraCount, Icons.add_circle_outline),
              ]),
              const SizedBox(height: 16),
              Align(alignment: Alignment.centerRight, child: Text('لفظ بہ لفظ نتیجہ', style: const TextStyle(fontWeight: FontWeight.bold))),
              const SizedBox(height: 8),
              Wrap(spacing: 6, runSpacing: 6, alignment: WrapAlignment.center, children: [for (final w in wordChecks) _wordChip(w)]),
              if (extraCount > 0) ...[
                const SizedBox(height: 12),
                Text('اضافی سنے گئے الفاظ: ${_alignWordsDetailed(_arabicWords(ayah['text']), _arabicWords(recognized)).extraWords.join('، ')}', textDirection: TextDirection.rtl, textAlign: TextAlign.center),
              ],
              const SizedBox(height: 14),
              OutlinedButton.icon(onPressed: startListening, icon: const Icon(Icons.refresh), label: const Text('دوبارہ تلاوت کریں')),
              const SizedBox(height: 10),
              const Text('یہ score صرف speech-recognition اور لفظی matching کی بنیاد پر ہے۔ یہ تجوید، مخارج، وقف و ابتدا یا قاری کی درست ادائیگی کی حتمی تصدیق نہیں کرتا۔', textDirection: TextDirection.rtl, textAlign: TextAlign.center, style: TextStyle(color: Colors.black54, height: 1.5)),
            ]))),
          ],
        ] else const SizedBox(height: 80),
      ]),
    );
  }

  Widget _statChip(String label, int value, IconData icon) => Chip(avatar: Icon(icon, size: 17), label: Text('$label: $value'));

  Widget _wordChip(_WordCheck w) {
    final icon = w.status == _WordStatus.match ? Icons.check_circle : w.status == _WordStatus.missing ? Icons.remove_circle : Icons.error;
    final label = w.status == _WordStatus.match ? w.expected : w.status == _WordStatus.missing ? '${w.expected} (نہیں سنا گیا)' : '${w.expected} ← ${w.heard}';
    return Chip(avatar: Icon(icon, size: 18), label: Text(label, textDirection: TextDirection.rtl));
  }
}

enum _WordStatus { match, missing, substitution }
class _WordCheck {
  final String expected;
  final String heard;
  final _WordStatus status;
  _WordCheck(this.expected, this.heard, this.status);
}

class _AlignmentResult {
  final List<_WordCheck> items;
  final List<String> extraWords;
  _AlignmentResult(this.items, this.extraWords);
}

_AlignmentResult _alignWordsDetailed(List<String> expected, List<String> heard) {
  final n = expected.length, m = heard.length;
  final dp = List.generate(n + 1, (_) => List<int>.filled(m + 1, 0));
  for (var i = 0; i <= n; i++) dp[i][0] = i;
  for (var j = 0; j <= m; j++) dp[0][j] = j;
  for (var i = 1; i <= n; i++) {
    for (var j = 1; j <= m; j++) {
      final cost = expected[i - 1] == heard[j - 1] ? 0 : 1;
      final del = dp[i - 1][j] + 1;
      final ins = dp[i][j - 1] + 1;
      final sub = dp[i - 1][j - 1] + cost;
      dp[i][j] = [del, ins, sub].reduce((a,b) => a < b ? a : b);
    }
  }
  final out = <_WordCheck>[];
  final extras = <String>[];
  var i = n, j = m;
  while (i > 0 || j > 0) {
    if (i > 0 && j > 0 && expected[i - 1] == heard[j - 1]) {
      out.add(_WordCheck(expected[i - 1], heard[j - 1], _WordStatus.match)); i--; j--;
    } else if (i > 0 && j > 0 && dp[i][j] == dp[i - 1][j - 1] + 1) {
      out.add(_WordCheck(expected[i - 1], heard[j - 1], _WordStatus.substitution)); i--; j--;
    } else if (i > 0 && dp[i][j] == dp[i - 1][j] + 1) {
      out.add(_WordCheck(expected[i - 1], '', _WordStatus.missing)); i--;
    } else {
      extras.add(heard[j - 1]); j--;
    }
  }
  return _AlignmentResult(out.reversed.toList(), extras.reversed.toList());
}

List<_WordCheck> _alignWords(List<String> expected, List<String> heard) => _alignWordsDetailed(expected, heard).items;


class TilawatPage extends StatefulWidget {
  final SharedPreferences prefs;
  final Future<QuranData> future;
  const TilawatPage({super.key, required this.prefs, required this.future});
  @override State<TilawatPage> createState() => _TilawatPageState();
}

class _TilawatPageState extends State<TilawatPage> {
  final audio = OfflineAudioManager.instance;
  int? selected;
  int? downloading;
  double? progress;
  String? error;

  Future<void> download(int n) async {
    if (downloading != null) return;
    setState(() { downloading = n; progress = 0; error = null; });
    try {
      await audio.download(n, onProgress: (received, total) {
        if (!mounted || downloading != n) return;
        setState(() => progress = total > 0 ? received / total : null);
      });
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('سورہ $n کی تلاوت Offline محفوظ ہو گئی۔')),
      );
    } catch (e) {
      if (mounted) {
        setState(() => error = e.toString());
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Download failed: $e')),
        );
      }
    } finally {
      if (mounted) setState(() { downloading = null; progress = null; });
    }
  }

  Future<void> play(int n) async {
    try {
      await audio.playSurah(n);
      if (mounted) setState(() => selected = n);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    }
  }

  Future<void> remove(int n) async {
    try {
      await audio.delete(n);
      if (mounted) {
        if (selected == n) setState(() => selected = null);
        setState(() {});
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('سورہ $n کی Offline audio حذف کر دی گئی۔')),
        );
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    }
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('تلاوت سنیں'), centerTitle: true),
    body: FutureBuilder<QuranData>(future: widget.future, builder: (context, snap) {
      if (!snap.hasData) return const Center(child: CircularProgressIndicator());
      final surahs = snap.data!.surahs;
      return Column(children: [
        Container(
          margin: const EdgeInsets.all(12),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: green.withOpacity(.10), borderRadius: BorderRadius.circular(18)),
          child: const Row(children: [
            Icon(Icons.download_for_offline, color: green), SizedBox(width: 10),
            Expanded(child: Text('ہر سورہ ایک بار Download کریں۔ Download مکمل ہونے کے بعد اسے Internet کے بغیر بھی چلایا جا سکتا ہے۔')),
          ]),
        ),
        Expanded(child: ListView.builder(itemCount: surahs.length, itemBuilder: (_, i) {
          final s = surahs[i];
          final n = s['number'] as int;
          final isDownloading = downloading == n;
          return FutureBuilder<bool>(
            future: audio.isDownloaded(n),
            builder: (_, dl) {
              final saved = dl.data == true;
              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                child: ListTile(
                  leading: CircleAvatar(backgroundColor: green, foregroundColor: Colors.white, child: Text('$n')),
                  title: Text(s['name'], textDirection: TextDirection.rtl, textAlign: TextAlign.right, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
                  subtitle: isDownloading
                      ? Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                          const Text('Download ہو رہی ہے...'),
                          const SizedBox(height: 5),
                          LinearProgressIndicator(value: progress),
                        ])
                      : Text(saved ? 'Offline محفوظ • ${s['ayahCount']} آیات' : 'Download کریں • ${s['ayahCount']} آیات', textAlign: TextAlign.right),
                  trailing: saved
                      ? PopupMenuButton<String>(
                          onSelected: (v) { if (v == 'play') play(n); if (v == 'delete') remove(n); },
                          itemBuilder: (_) => const [
                            PopupMenuItem(value: 'play', child: Text('چلائیں')),
                            PopupMenuItem(value: 'delete', child: Text('Offline audio حذف کریں')),
                          ],
                          icon: const Icon(Icons.more_vert, color: green),
                        )
                      : IconButton(
                          onPressed: isDownloading || downloading != null ? null : () => download(n),
                          icon: Icon(isDownloading ? Icons.downloading : Icons.download_for_offline, color: green, size: 32),
                        ),
                  onTap: saved ? () => play(n) : (isDownloading || downloading != null ? null : () => download(n)),
                ),
              );
            },
          );
        })),
        StreamBuilder<PlayerState>(stream: audio.player.playerStateStream, builder: (_, state) {
          if (selected == null) return const SizedBox.shrink();
          final playing = state.data?.playing == true;
          return SafeArea(child: Container(
            color: Colors.white,
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            child: Row(children: [
              Expanded(child: Text('سورہ $selected', style: const TextStyle(fontWeight: FontWeight.bold))),
              IconButton(onPressed: playing ? audio.player.pause : () => play(selected!), icon: Icon(playing ? Icons.pause : Icons.play_arrow, color: green)),
              IconButton(onPressed: audio.player.stop, icon: const Icon(Icons.stop)),
            ]),
          ));
        }),
      ]);
    }),
  );
}

class BookmarksPage extends StatefulWidget { final SharedPreferences prefs; final Future<QuranData> future; const BookmarksPage({super.key,required this.prefs,required this.future}); @override State<BookmarksPage> createState()=>_BookmarksPageState(); }
class _BookmarksPageState extends State<BookmarksPage>{
  @override Widget build(BuildContext context)=>FutureBuilder<QuranData>(future:widget.future,builder:(context,snap){if(!snap.hasData)return const Scaffold(body:Center(child:CircularProgressIndicator())); final keys=widget.prefs.getStringList('bookmarks')??[]; final rows=<Map<String,dynamic>>[]; for(final s in snap.data!.surahs){for(final a in (s['ayahs'] as List)){final k='${s['number']}:${a['number']}';if(keys.contains(k))rows.add({'key':k,'surah':s,'ayah':a});}} return Scaffold(appBar:AppBar(title:const Text('محفوظ آیات')),body:rows.isEmpty?const Center(child:Text('ابھی کوئی آیت محفوظ نہیں کی گئی')):ListView.builder(padding:const EdgeInsets.all(12),itemCount:rows.length,itemBuilder:(_,i){final r=rows[i];return Card(margin:const EdgeInsets.only(bottom:10),child:ListTile(title:Text(r['ayah']['text'],textDirection:TextDirection.rtl,textAlign:TextAlign.right,maxLines:3,overflow:TextOverflow.ellipsis),subtitle:Text('سورہ ${r['surah']['name']} • آیت ${r['ayah']['number']}'),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>SurahPage(prefs:widget.prefs,surah:r['surah']))));}));});
}

class ProgressPage extends StatefulWidget { final SharedPreferences prefs; final bool embedded; const ProgressPage({super.key,required this.prefs,this.embedded=false}); @override State<ProgressPage> createState()=>_ProgressPageState(); }
class _ProgressPageState extends State<ProgressPage>{
  Map<String,int> get stats {
    final opened=(widget.prefs.getStringList('opened_surahs')??[]).length;
    final bookmarks=(widget.prefs.getStringList('bookmarks')??[]).length;
    final history=widget.prefs.getStringList('practice_history')??[];
    var attempts=history.length, totalMatched=0, totalWords=0;
    for(final raw in history){
      try { final m=jsonDecode(raw); totalMatched += (m['matched'] as num?)?.toInt() ?? 0; totalWords += (m['total'] as num?)?.toInt() ?? 0; } catch (_) {}
    }
    return {'opened':opened,'bookmarks':bookmarks,'attempts':attempts,'matched':totalMatched,'words':totalWords};
  }
  @override Widget build(BuildContext context){
    final st=stats; final openedPct=st['opened']!/114; final practicePct=st['words']!>0?st['matched']!/st['words']!:0.0;
    final lastSurah=widget.prefs.getInt('last_surah'); final lastAyah=widget.prefs.getInt('last_ayah');
    final body=ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        const Text('قرآن پڑھنے کی پیش رفت',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),const SizedBox(height:10),
        LinearProgressIndicator(value:openedPct.clamp(0,1),minHeight:12,color:green,backgroundColor:green.withOpacity(.12)),const SizedBox(height:8),
        Text('${st['opened']} / 114 سورتیں کھولی گئی ہیں'),const SizedBox(height:4),const Text('یہ count ان سورتوں پر مبنی ہے جنہیں آپ نے app میں کھولا ہے۔')]))),
      _stat('Bookmarks', (st['bookmarks']!/100).clamp(0.0,1.0), '${st['bookmarks']} آیات محفوظ'),
      Card(child:ListTile(leading:const Icon(Icons.record_voice_over,color:green),title:const Text('Reading Practice'),subtitle:Text('${st['attempts']} practice attempts • ${st['matched']} / ${st['words']} words matched'),trailing:SizedBox(width:70,child:LinearProgressIndicator(value:practicePct.clamp(0,1),minHeight:8,color:green)))),
      if(lastSurah!=null) Card(child:ListTile(leading:const Icon(Icons.history,color:green),title:const Text('آخری پڑھی گئی سورت'),subtitle:Text('سورت $lastSurah${lastAyah!=null?' • آیت $lastAyah':''}'))),
      Card(child:ListTile(leading:const Icon(Icons.cloud_off,color:green),title:const Text('Offline Quran'),subtitle:const Text('Arabic Quran text app کے اندر محفوظ ہے۔'))),
      const SizedBox(height:12),OutlinedButton.icon(onPressed:()async{await widget.prefs.remove('last_surah');await widget.prefs.remove('last_ayah');await widget.prefs.remove('bookmarks');await widget.prefs.remove('opened_surahs');await widget.prefs.remove('practice_history');setState((){});},icon:const Icon(Icons.restart_alt),label:const Text('تمام Progress Reset کریں'))
    ]); if(widget.embedded)return Scaffold(body:body);return Scaffold(appBar:AppBar(title:const Text('میری پیش رفت')),body:body); }
  Widget _stat(String t,double v,String s)=>Card(margin:const EdgeInsets.only(bottom:12),child:Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(t,style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold)),const SizedBox(height:10),LinearProgressIndicator(value:v.clamp(0,1),minHeight:10,color:green,backgroundColor:green.withOpacity(.12)),const SizedBox(height:7),Text(s)])));
}

class SettingsPage extends StatefulWidget { final SharedPreferences prefs; final bool embedded; const SettingsPage({super.key,required this.prefs,this.embedded=false}); @override State<SettingsPage> createState()=>_SettingsPageState(); }
class _SettingsPageState extends State<SettingsPage>{ bool dark=false; @override void initState(){super.initState();dark=widget.prefs.getBool('dark')??false;} @override Widget build(BuildContext context){final body=ListView(padding:const EdgeInsets.all(16),children:[Card(child:SwitchListTile(title:const Text('Dark Mode'),value:dark,onChanged:(v)async{setState(()=>dark=v);await widget.prefs.setBool('dark',v);},secondary:const Icon(Icons.dark_mode))),Card(child:ListTile(leading:const Icon(Icons.privacy_tip),title:const Text('Privacy Policy'),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const PrivacyPage())))),Card(child:ListTile(leading:const Icon(Icons.info_outline),title:const Text('About Quran Seekho'),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const AboutPage()))))]);if(widget.embedded)return Scaffold(body:body);return Scaffold(appBar:AppBar(title:const Text('Settings')),body:body);}}
class PrivacyPage extends StatelessWidget{const PrivacyPage({super.key});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Privacy Policy')),body:const SingleChildScrollView(padding:EdgeInsets.all(18),child:Text('Quran Seekho Privacy Policy\n\nThis app stores reading progress and bookmarks locally on your device. The bundled Quran text is read from local app assets and does not require internet access. The app does not require an account for offline Quran reading.\n\nIf future versions add online services, their data practices will be described here before release. You can clear saved progress from the Progress screen or by removing the app data.\n\nLast updated: 22 September 2026',style:TextStyle(fontSize:16,height:1.6))));}
class AboutPage extends StatelessWidget{const AboutPage({super.key});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('About')),body:const SingleChildScrollView(padding:EdgeInsets.all(18),child:Text('Quran Seekho\n\nA simple Quran reading and learning app focused on offline Arabic Quran reading.\n\nQuran text attribution\nThe bundled Uthmani Quran text is attributed to the Tanzil Project. The required source and license notice must be retained.\n\nSource: https://tanzil.net/\nLicense: CC BY 3.0\nLicense details: https://tanzil.net/docs/Text_License\n\nTilawat audio\nAudio is downloaded at runtime from QuranicAudio.com. Their site states that MP3s may be used for personal use but commercial use can be restricted by recording/rightsholder terms. Audio rights must be verified for the intended public release.\n\nAudio source: https://quranicaudio.com/\nUsage information: https://quranicaudio.com/about\n\nSee LICENSES.md in the project for the complete third-party notice.')));}
class MenuPage extends StatelessWidget {
  final SharedPreferences prefs;
  final Future<QuranData> future;
  const MenuPage({super.key, required this.prefs, required this.future});

  void _go(BuildContext context, Widget page) {
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Menu')),
    body: ListView(padding: const EdgeInsets.symmetric(vertical: 8), children: [
      _item(context, Icons.home, 'Home', 'قرآن سیکھو', () => Navigator.pop(context)),
      _item(context, Icons.menu_book, 'Quran', 'قرآن پاک پڑھیں', () => _go(context, QuranPage(prefs: prefs, future: future))),
      _item(context, Icons.headphones, 'Tilawat Audio', 'تلاوت سنیں / Offline Audio', () => _go(context, TilawatPage(prefs: prefs, future: future))),
      _item(context, Icons.bookmark, 'Bookmarks', 'محفوظ آیات', () => _go(context, BookmarksPage(prefs: prefs, future: future))),
      _item(context, Icons.volunteer_activism, 'Daily Duas', 'روزانہ کی دعائیں', () => _go(context, const DuasPage())),
      _item(context, Icons.record_voice_over, 'Reading Practice', 'اپنی تلاوت چیک کریں', () => _go(context, ReadingPracticePage(prefs: prefs, future: future))),
      _item(context, Icons.insights, 'Progress', 'میری پیش رفت', () => _go(context, ProgressPage(prefs: prefs))),
      _item(context, Icons.settings, 'Settings', 'سیٹنگز', () => _go(context, SettingsPage(prefs: prefs))),
    ]),
  );

  Widget _item(BuildContext context, IconData icon, String title, String subtitle, VoidCallback onTap) =>
    Card(margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 5), child: ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 5),
      leading: CircleAvatar(backgroundColor: green.withOpacity(.12), child: Icon(icon, color: green)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
      subtitle: Text(subtitle, textDirection: TextDirection.rtl, textAlign: TextAlign.right),
      trailing: const Icon(Icons.chevron_right),
      onTap: onTap,
    ));
}
