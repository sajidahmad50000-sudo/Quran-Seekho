# Quran Seekho — Third-Party Notices & Release Licensing

## 1. Bundled Quran Arabic text

The bundled Uthmani Quran text is attributed to the **Tanzil Project**.

Copyright (C) 2007-2021 Tanzil Project
License: Creative Commons Attribution 3.0 (CC BY 3.0)

Tanzil's terms require the source to be clearly indicated, a link to Tanzil to be provided, and the copyright notice to be included with copies/derivatives containing a substantial portion of the text. Tanzil also states that verbatim copies may be distributed but the Quran text itself must not be changed.

Source: https://tanzil.net/
License details: https://tanzil.net/docs/Text_License
Uthmani text details: https://tanzil.net/docs/Uthmani

## 2. Quran recitation audio

The app currently downloads recitation audio at runtime from QuranicAudio.com. The configured reciter is **Abdullah Awad al-Juhani**.

QuranicAudio.com states that its MP3 files may be downloaded and used for personal use free of charge, while commercial use is restricted because individual files may have rights held by publishers/rightsholders.

Source: https://quranicaudio.com/
Terms/usage statement: https://quranicaudio.com/about

**Release requirement:** Do not advertise, bundle, redistribute, or use the downloaded recitation audio for a commercial/public release until the rights for the specific recording and intended distribution model have been verified or permission has been obtained from the applicable rightsholder(s).

The app does not bundle these MP3 files in the source ZIP; it downloads them at runtime.

## 3. Flutter and package dependencies

This project uses Flutter and packages declared in `pubspec.yaml`. Before a public release, run the package/license audit for the exact resolved dependency versions and retain their required notices.

## 4. App-created content

The app's UI code, original screens, local progress/bookmark logic, and app-specific documentation are part of the Quran Seekho project unless a file states otherwise.

## 5. Final release checklist

Before publishing an APK/AAB:

- [ ] Verify the exact bundled Quran text matches the intended Tanzil release.
- [ ] Keep this notice and the Tanzil attribution in the distributed app.
- [ ] Include a working Tanzil link in the About/Credits screen.
- [ ] Verify the specific audio recording rights for the intended release; do not assume personal-use permission covers commercial/public distribution.
- [ ] Generate the final dependency license report from the exact Flutter lockfile.
- [ ] Review Android/Google Play policy requirements, privacy disclosures, app signing, package name, version, and data-safety declarations.
- [ ] Run `flutter analyze` and `flutter build apk --release` (or AAB) on a machine with the required Flutter/Android SDK.
