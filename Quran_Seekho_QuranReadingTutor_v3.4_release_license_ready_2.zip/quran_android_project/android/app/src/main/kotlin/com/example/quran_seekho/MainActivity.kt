package com.example.quran_seekho

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
